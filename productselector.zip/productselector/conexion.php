<?php
$servidor = "localhost";
$usuario = "root";
$clave = "";
$baseDatos = "ProductSelector";

$conn = new mysqli($servidor, $usuario, $clave, $baseDatos);

if ($conn->connect_error) {
    if (strpos($_SERVER['SCRIPT_NAME'], 'verificar_codigo.php') !== false) {
        header('Content-Type: text/plain; charset=utf-8');
        echo "error_conexion";
        exit;
    }
    die("❌ Error de conexión: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
?>
