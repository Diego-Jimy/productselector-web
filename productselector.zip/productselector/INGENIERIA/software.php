<?php include '../conexion.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Ingeniería de Software | TecShop</title>
  <link rel="stylesheet" href="../style.css?v=<?= time(); ?>">
  <link rel="icon" href="../img/favicon.ico" type="image/x-icon"/>
</head>

<body>
  <header>
    <div class="header-content">
      <img src="../img/logo.png" class="logo" alt="TecShop Logo">
      <h1>Ingeniería de Software</h1>
    </div>
  </header>

  <section class="filtros">
    <button class="filtro-btn active" data-cat="todos">Todos</button>
    <button class="filtro-btn" data-cat="corei5">Core i5</button>
    <button class="filtro-btn" data-cat="corei7">Core i7</button>
    <button class="filtro-btn" data-cat="ryzen5">Ryzen 5</button>
    <button class="filtro-btn" data-cat="ryzen7">Ryzen 7</button>
  </section>

  <main>
    <?php
    $sqlTodos = "
      SELECT l.id, l.nombre, l.precio, l.imagen, p.nombre AS procesador, d.descripcion
      FROM laptops l
      JOIN procesadores p ON l.procesador_id = p.id
      LEFT JOIN detalles d ON d.laptop_id = l.id
      ORDER BY l.precio ASC
    ";
    $resultTodos = $conn->query($sqlTodos);
    $todos = [];
    if ($resultTodos && $resultTodos->num_rows > 0) {
      while ($row = $resultTodos->fetch_assoc()) {
        $todos[] = $row;
      }
    }

    $sql = "
      SELECT l.id, l.nombre, l.precio, l.imagen, p.nombre AS procesador, d.descripcion
      FROM laptops l
      JOIN procesadores p ON l.procesador_id = p.id
      LEFT JOIN detalles d ON d.laptop_id = l.id
      WHERE p.nombre LIKE '%i5%'
         OR p.nombre LIKE '%i7%'
         OR p.nombre LIKE '%ryzen 5%'
         OR p.nombre LIKE '%ryzen 7%'
      ORDER BY l.precio ASC
    ";
    $result = $conn->query($sql);

    $corei5 = $corei7 = $ryzen5 = $ryzen7 = [];

    if ($result && $result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        $proc = strtolower($row['procesador']);
        if (strpos($proc, 'i5') !== false)      $corei5[] = $row;
        if (strpos($proc, 'i7') !== false)      $corei7[] = $row;
        if (strpos($proc, 'ryzen 5') !== false) $ryzen5[] = $row;
        if (strpos($proc, 'ryzen 7') !== false) $ryzen7[] = $row;
      }
    }

    function renderCat($clase, $items, $mensaje, $visible = false) {
      $show = $visible ? "" : "style='display:none;'";
      echo "<section class='categoria $clase' $show><div class='grid'>";
      if (!empty($items)) {
        foreach ($items as $item) {
          $descripcion = htmlspecialchars($item['descripcion'] ?? '');
          echo '
          <a class="card" href="../detalles/detalle-laptop.php?id=' . $item['id'] . '">
            <img src="../img/laptops/' . htmlspecialchars($item['imagen']) . '?v=' . time() . '"
                 alt="' . htmlspecialchars($item['nombre']) . '"
                 onerror="this.src=\'../img/laptop.png\'"/>
            <h2>' . htmlspecialchars($item['nombre']) . '</h2>';
          if (!empty($descripcion)) {
            echo '<p class="descripcion"><strong>Descripción:</strong> ' . $descripcion . '</p>';
          }
          echo '<p class="price-oferta">S/ ' . number_format($item['precio'], 2) . '</p>
          </a>';
        }
      } else {
        echo "<p class='mensaje-vacio'>$mensaje</p>";
      }
      echo "</div></section>";
    }

    renderCat("todos", $todos,  "No hay laptops disponibles.", true);
    renderCat("corei5", $corei5, "No hay laptops Intel Core i5 disponibles.");
    renderCat("corei7", $corei7, "No hay laptops Intel Core i7 disponibles.");
    renderCat("ryzen5", $ryzen5, "No hay laptops AMD Ryzen 5 disponibles.");
    renderCat("ryzen7", $ryzen7, "No hay laptops AMD Ryzen 7 disponibles.");
    ?>
  </main>

  <a class="volver" href="ingenieria.html">⬅ Volver</a>

  <footer>
    <p>&copy; <?= date('Y') ?> TecShop. Todos los derechos reservados.</p>
  </footer>

  <script>
    document.addEventListener("DOMContentLoaded", () => {
      const buttons = document.querySelectorAll(".filtro-btn");
      const categories = document.querySelectorAll(".categoria");

      buttons.forEach(btn => {
        btn.addEventListener("click", () => {
          buttons.forEach(b => b.classList.remove("active"));
          btn.classList.add("active");

          const cat = btn.dataset.cat;
          categories.forEach(sec => {
            sec.style.display = sec.classList.contains(cat) ? "block" : "none";
          });
        });
      });
    });
  </script>

  <style>
    .descripcion {
      font-size: 0.9rem;
      color: #444;
      margin: 6px 0;
      line-height: 1.4em;
    }
    .descripcion strong {
      color: #0288d1;
    }
  </style>

</body>
</html>
<?php $conn->close(); ?>