<?php include '../conexion.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <meta name="description" content="Encuentra laptops ideales para Ingeniería Mecánica (AutoCAD, SolidWorks, Inventor, ANSYS) en TecShop."/>
  <title>Ingeniería Mecánica | TecShop</title>
  <link href="../style.css?v=<?= time(); ?>" rel="stylesheet"/>
</head>

<body>
  <header>
    <div class="header-content">
      <img src="../img/logo.png" alt="Logo TecShop" class="logo">
      <h1>Ingeniería Mecánica</h1>
    </div>
  </header>

  <section class="filtros">
    <button class="filtro-btn active" data-cat="todos">Todos</button>
    <button class="filtro-btn" data-cat="corei5">Core i5</button>
    <button class="filtro-btn" data-cat="corei7">Core i7</button>
    <button class="filtro-btn" data-cat="ryzen5">Ryzen 5</button>
    <button class="filtro-btn" data-cat="ryzen7">Ryzen 7</button>
  </section>

  <main>
    <?php
    $sql = "
      SELECT l.id, l.nombre, l.precio, l.imagen, p.nombre AS procesador, d.descripcion
      FROM laptops l
      JOIN procesadores p ON l.procesador_id = p.id
      LEFT JOIN detalles d ON d.laptop_id = l.id
      WHERE p.nombre IN ('Intel Core i5', 'Intel Core i7', 'AMD Ryzen 5', 'AMD Ryzen 7')
      ORDER BY l.precio ASC
    ";
    $result = $conn->query($sql);

    $corei5 = $corei7 = $ryzen5 = $ryzen7 = [];

    if ($result && $result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        $p = strtolower($row['procesador']);
        if (str_contains($p, 'i5'))        $corei5[] = $row;
        elseif (str_contains($p, 'i7'))    $corei7[] = $row;
        elseif (str_contains($p, 'ryzen 5')) $ryzen5[] = $row;
        elseif (str_contains($p, 'ryzen 7')) $ryzen7[] = $row;
      }
    }

    $todos = [];
    $sqlTodos = "
      SELECT l.id, l.nombre, l.precio, l.imagen, p.nombre AS procesador, d.descripcion
      FROM laptops l
      JOIN procesadores p ON l.procesador_id = p.id
      LEFT JOIN detalles d ON d.laptop_id = l.id
      ORDER BY l.precio ASC
    ";
    $resultTodos = $conn->query($sqlTodos);
    if ($resultTodos && $resultTodos->num_rows > 0) {
      while ($row = $resultTodos->fetch_assoc()) {
        $todos[] = $row;
      }
    }

    function renderCat($clase, $items, $mensaje) {
      $mostrar = ($clase === "todos") ? "" : "style='display:none;'";
      echo "<section class='categoria $clase' $mostrar><div class='grid'>";
      if (!empty($items)) {
        foreach ($items as $item) {
          $nombre = htmlspecialchars($item['nombre']);
          $imagen = htmlspecialchars($item['imagen']);
          $precio = number_format($item['precio'], 2);
          $descripcion = htmlspecialchars($item['descripcion'] ?? '');
          echo "
          <a class='card' href='../detalles/detalle-laptop.php?id={$item['id']}'>
            <img src='../img/laptops/$imagen?v=".time()."' 
                 alt='$nombre'
                 onerror=\"this.src='../img/laptop.png'\"/>
            <h2>$nombre</h2>";
          if (!empty($descripcion)) {
            echo "<p class='descripcion'><strong>Descripción:</strong> $descripcion</p>";
          }
          echo "<p class='price-oferta'>S/ $precio</p>
          </a>";
        }
      } else {
        echo "<p class='mensaje-vacio'>$mensaje</p>";
      }
      echo "</div></section>";
    }

    renderCat("todos", $todos, "No hay laptops disponibles.");
    renderCat("corei5", $corei5, "No hay laptops Intel Core i5 disponibles.");
    renderCat("corei7", $corei7, "No hay laptops Intel Core i7 disponibles.");
    renderCat("ryzen5", $ryzen5, "No hay laptops AMD Ryzen 5 disponibles.");
    renderCat("ryzen7", $ryzen7, "No hay laptops AMD Ryzen 7 disponibles.");
    ?>
  </main>

  <a class="volver" href="../INGENIERIA/ingenieria.html">⬅ Volver</a>

  <footer>
    <p>&copy; <?= date('Y') ?> TecShop. Todos los derechos reservados.</p>
  </footer>

  <script>
    document.addEventListener("DOMContentLoaded", () => {
      const buttons = document.querySelectorAll(".filtro-btn");
      const categorias = document.querySelectorAll(".categoria");

      buttons.forEach(btn => {
        btn.addEventListener("click", () => {
          buttons.forEach(b => b.classList.remove("active"));
          btn.classList.add("active");

          const cat = btn.dataset.cat;

          categorias.forEach(sec => {
            sec.style.display = sec.classList.contains(cat) ? "block" : "none";
          });
        });
      });
    });
  </script>

  <style>
    .descripcion {
      font-size: 0.9rem;
      color: #444;
      margin: 6px 0;
      line-height: 1.4em;
    }
    .descripcion strong {
      color: #0288d1;
    }
  </style>
</body>
</html>
<?php $conn->close(); ?>