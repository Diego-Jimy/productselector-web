<?php
include '../conexion.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Teclado - TecShop</title>
  <link href="../componentes.css" rel="stylesheet"/>
</head>

<body>
  <header>
    <h1>Teclado</h1>
    <span class="cart-icon" onclick="toggleCart()">🛒</span>
    <div class="cart-panel" id="cartPanel"></div>
  </header>

  
  <section class="filtros" style="text-align:center; margin:20px;">
    <?php
    $subcats = $conn->query("SELECT id, nombre FROM subcategorias WHERE categoria_id = 8 ORDER BY nombre ASC");

    if ($subcats && $subcats->num_rows > 0) {
      $primera = true;
      while ($sub = $subcats->fetch_assoc()) {
        $activeClass = $primera ? "active" : "";
        echo "<button class='filtro-btn $activeClass' data-cat='sub{$sub['id']}'>" . htmlspecialchars($sub['nombre']) . "</button>";
        $primera = false;
      }
    } else {
      echo "<p>No hay subcategorías registradas para teclados.</p>";
    }
    ?>
  </section>

  <main>
    <?php
    
    $subcats = $conn->query("SELECT id, nombre FROM subcategorias WHERE categoria_id = 8 ORDER BY nombre ASC");

    if ($subcats && $subcats->num_rows > 0) {
      $primera = true;

      while ($sub = $subcats->fetch_assoc()) {
        $subId = (int)$sub['id'];
        $subNombre = htmlspecialchars($sub['nombre']);

        
        $sql = "SELECT * FROM productos WHERE categoria_id = 8 AND subcategoria_id = $subId AND tipo = 'pc'";
        $result = $conn->query($sql);

        echo "<section class='categoria sub{$subId}' style='" . ($primera ? "" : "display:none;") . "'>";
        echo "<h2 style='text-align:center; color:#0f6a91;'>$subNombre</h2>";
        echo "<div class='grid'>";

        if ($result && $result->num_rows > 0) {
          while ($item = $result->fetch_assoc()) {
            echo "
            <div class='card'>
              <img src='../img/" . htmlspecialchars($item['imagen']) . "' alt='" . htmlspecialchars($item['nombre']) . "'>
              <h2>" . htmlspecialchars($item['nombre']) . "</h2>
              <p>" . htmlspecialchars($item['descripcion']) . "</p>
              <p class='price'>S/ " . number_format($item['precio'], 2) . "</p>
              <button class='add-btn' onclick='addToCart(" . json_encode($item['nombre']) . ", " . json_encode((float)$item['precio']) . ")'>+</button>
            </div>";
          }
        } else {
          echo "<p style='text-align:center;'>No hay productos disponibles en esta subcategoría.</p>";
        }

        echo "</div></section>";
        $primera = false;
      }
    } else {
      echo "<p style='text-align:center;'>No hay subcategorías disponibles para teclados.</p>";
    }
    ?>
  </main>

  <a class="volver" href="../pc.html">⬅ Volver</a>

  <footer>
    <p>&copy; 2025 TecShop. Todos los derechos reservados.</p>
  </footer>

  <script src="../cart.js"></script>

  <script>
  document.addEventListener("DOMContentLoaded", () => {
    const buttons = document.querySelectorAll(".filtro-btn");
    const categories = document.querySelectorAll(".categoria");

    if (buttons.length > 0) buttons[0].classList.add("active");

    buttons.forEach(btn => {
      btn.addEventListener("click", () => {
        buttons.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");

        const cat = btn.dataset.cat;
        categories.forEach(sec => {
          sec.style.display = sec.classList.contains(cat) ? "block" : "none";
        });
      });
    });
  });
  </script>

</body>
</html>

<?php $conn->close(); ?>
