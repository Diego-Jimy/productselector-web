<?php
include '../conexion.php';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id <= 0) {
  echo "<body><h2 style='text-align:center;margin-top:40px;'>❌ ID no válido.</h2><p style='text-align:center;'><a href='../carreras.html'>⬅ Volver al catálogo</a></p></body>";
  exit;
}
$sql = "SELECT l.id, l.nombre, l.precio, l.imagen, p.nombre AS procesador, d.marca, d.ram, d.almacenamiento, d.pantalla, d.sistema_operativo, d.bateria 
        FROM laptops l 
        LEFT JOIN procesadores p ON l.procesador_id = p.id 
        LEFT JOIN detalles d ON d.laptop_id = l.id 
        WHERE l.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$laptop = $stmt->get_result()->fetch_assoc();
if (!$laptop) {
  echo "<body><h2 style='text-align:center;margin-top:40px;'>❌ Laptop no encontrada.</h2><p style='text-align:center;'><a href='../carreras.html'>⬅ Volver al catálogo</a></p></body>";
  exit;
}
$imagen = !empty($laptop['imagen']) ? $laptop['imagen'] : 'laptop.png';

$sqlImgs = "SELECT imagen FROM laptop_imagenes WHERE laptop_id = ? ORDER BY id ASC";
$stmtImgs = $conn->prepare($sqlImgs);
$stmtImgs->bind_param("i", $id);
$stmtImgs->execute();
$resImgs = $stmtImgs->get_result();
$imagenesExtras = [];
while ($row = $resImgs->fetch_assoc()) {
  $imagenesExtras[] = "../img/laptops/" . htmlspecialchars($row['imagen']);
}

$sqlProgramas = "SELECT pr.nombre, pr.icono FROM laptop_programa lp JOIN programas pr ON pr.id = lp.programa_id WHERE lp.laptop_id = ?";
$stmtProg = $conn->prepare($sqlProgramas);
$stmtProg->bind_param("i", $id);
$stmtProg->execute();
$programas = $stmtProg->get_result();

$sqlCarreras = "SELECT c.nombre FROM laptop_carreras lc JOIN carreras c ON c.id = lc.carrera_id WHERE lc.laptop_id = ? ORDER BY c.nombre";
$stmtCarr = $conn->prepare($sqlCarreras);
$stmtCarr->bind_param("i", $id);
$stmtCarr->execute();
$carreras = $stmtCarr->get_result();

$sqlVentas = "SELECT enero, febrero, marzo, abril, mayo, junio, julio, agosto, septiembre, octubre, noviembre, diciembre FROM ventas WHERE laptop_id = ?";
$stmtV = $conn->prepare($sqlVentas);
$stmtV->bind_param("i", $id);
$stmtV->execute();
$resultV = $stmtV->get_result();
$ventas = [];
if ($fila = $resultV->fetch_assoc()) {
  foreach ($fila as $mes => $valor) {
    $ventas[] = ['mes' => ucfirst($mes), 'cantidad' => (int)$valor];
  }
}
$stmt->close();
$stmtProg->close();
$stmtCarr->close();
$stmtV->close();
$stmtImgs->close();
$volver = $_SERVER['HTTP_REFERER'] ?? '../carreras.html';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title><?= htmlspecialchars($laptop['nombre']) ?> | TecShop</title>
<link rel="icon" href="../img/favicon.ico">
<link href="../style.css" rel="stylesheet"/>
<link href="../detalles.css" rel="stylesheet"/>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
.fullscreen-carousel {
  display: none;
  position: fixed;
  inset: 0;
  background: transparent;
  justify-content: center;
  align-items: center;
  z-index: 9999;
  overflow: hidden;
}
.fullscreen-carousel.active {
  display: flex;
}
.fullscreen-carousel img {
  width: 100vw;
  height: 100vh;
  object-fit: contain;
  cursor: zoom-out;
  transition: opacity 0.3s ease;
}
.nav-btn {
  position: fixed;
  top: 50%;
  transform: translateY(-50%);
  background: rgba(255,255,255,0.2);
  color: #fff;
  border: none;
  font-size: 2.5rem;
  padding: 10px 16px;
  border-radius: 50%;
  cursor: pointer;
  transition: background 0.3s;
  user-select: none;
  z-index: 10000;
}
.nav-btn:hover {
  background: rgba(255,255,255,0.4);
}
.nav-btn.prev { left: 25px; }
.nav-btn.next { right: 25px; }
.close-btn {
  position: fixed;
  top: 20px;
  right: 30px;
  font-size: 2.5rem;
  color: white;
  cursor: pointer;
  user-select: none;
  z-index: 10000;
}
.close-btn:hover { color: #26ABE2; }
</style>
</head>
<body>
<header>
<h1><?= htmlspecialchars(trim(($laptop['marca'] ?? '') . ' ' . $laptop['nombre'])) ?> 💻</h1>
</header>
<div class="detalle-layout">
<div id="ventas" class="section">
<h2>📊 Ventas</h2>
<canvas id="salesChart"></canvas>
</div>
<div id="caracter" class="section">
<h2>📋 Características</h2>
<ul>
<li>Procesador: <?= htmlspecialchars($laptop['procesador'] ?? '—') ?></li>
<li>RAM: <?= htmlspecialchars($laptop['ram'] ?? '—') ?></li>
<li>Almacenamiento: <?= htmlspecialchars($laptop['almacenamiento'] ?? '—') ?></li>
<li>Pantalla: <?= htmlspecialchars($laptop['pantalla'] ?? '—') ?></li>
<li>Sistema Operativo: <?= htmlspecialchars($laptop['sistema_operativo'] ?? '—') ?></li>
<li>Batería: <?= htmlspecialchars($laptop['bateria'] ?? '—') ?></li>
<li>💰 Precio: <strong>S/ <?= number_format($laptop['precio'], 2) ?></strong></li>
</ul>
</div>
<div class="laptop-img">
<img src="../img/laptops/<?= htmlspecialchars($imagen) ?>" alt="<?= htmlspecialchars($laptop['nombre']) ?>" onclick="openCarousel(this.src)" style="cursor: zoom-in;" onerror="this.src='../img/laptop.png'"/>
</div>
<div id="carreras" class="section">
<h2>🎓 Carreras recomendadas</h2>
<?php if ($carreras->num_rows > 0): ?>
<ul>
<?php while ($c = $carreras->fetch_assoc()): ?>
<li><?= htmlspecialchars($c['nombre']) ?></li>
<?php endwhile; ?>
</ul>
<?php else: ?>
<p>No se han asignado carreras a esta laptop.</p>
<?php endif; ?>
</div>
<div id="programs" class="section">
<h2>🖥️ Programas Compatibles</h2>
<div class="program-grid">
<?php if ($programas->num_rows > 0): ?>
<?php while ($p = $programas->fetch_assoc()): ?>
<div>
<img src="../img/programas/<?= htmlspecialchars($p['icono'] ?: 'programa.png') ?>" alt="<?= htmlspecialchars($p['nombre']) ?>">
<span><?= htmlspecialchars($p['nombre']) ?></span>
</div>
<?php endwhile; ?>
<?php else: ?>
<p>No hay programas asociados a esta laptop.</p>
<?php endif; ?>
</div>
</div>
</div>
<a class="volver" href="<?= htmlspecialchars($volver) ?>">⬅ Volver</a>
<footer>
<p>&copy; <?= date('Y') ?> TecShop. Todos los derechos reservados.</p>
</footer>
<div id="fullscreenCarousel" class="fullscreen-carousel">
<button class="nav-btn prev" onclick="changeImage(-1)">&#10094;</button>
<img id="carouselImg" src="" alt="Laptop" />
<button class="nav-btn next" onclick="changeImage(1)">&#10095;</button>
<span class="close-btn" onclick="closeCarousel()">&times;</span>
</div>
<script>
const ventas = <?= json_encode($ventas) ?>;
const labels = ventas.map(v => v.mes);
const data = ventas.map(v => v.cantidad);
new Chart(document.getElementById('salesChart'), {
  type: 'bar',
  data: { labels: labels, datasets: [{ data: data, borderColor: '#2563eb', backgroundColor: 'rgba(15,231,51,0.93)' }] },
  options: { plugins: { legend: { display: false } }, scales: { x: { grid: { display: false } }, y: { ticks: { stepSize: 5 } } } }
});
const imageList = [
  "../img/laptops/<?= htmlspecialchars($imagen) ?>",
  <?php foreach ($imagenesExtras as $img) echo "'$img',"; ?>
];
let currentIndex = 0;
function openCarousel(src) {
  const modal = document.getElementById("fullscreenCarousel");
  const img = document.getElementById("carouselImg");
  currentIndex = imageList.indexOf(src);
  if (currentIndex < 0) currentIndex = 0;
  img.src = imageList[currentIndex];
  modal.classList.add("active");
  if (modal.requestFullscreen) modal.requestFullscreen();
}
function changeImage(dir) {
  currentIndex = (currentIndex + dir + imageList.length) % imageList.length;
  const img = document.getElementById("carouselImg");
  img.style.opacity = "0";
  setTimeout(() => { img.src = imageList[currentIndex]; img.style.opacity = "1"; }, 150);
}
function closeCarousel() {
  const modal = document.getElementById("fullscreenCarousel");
  modal.classList.remove("active");
  if (document.exitFullscreen) document.exitFullscreen();
}
document.addEventListener("keydown", e => {
  if (!document.fullscreenElement) return;
  if (e.key === "Escape") closeCarousel();
  if (e.key === "ArrowRight") changeImage(1);
  if (e.key === "ArrowLeft") changeImage(-1);
});
</script>
</body>
</html>
<?php $conn->close(); ?>
