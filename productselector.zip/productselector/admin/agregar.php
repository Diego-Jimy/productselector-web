<?php
include '../conexion.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // 🔹 Recibir y limpiar datos del formulario
    $nombre = trim($_POST['nombre'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $precio = floatval($_POST['precio'] ?? 0);
    $categoria_id = intval($_POST['categoria_id'] ?? 0);
    $subcategoria_id = intval($_POST['subcategoria_id'] ?? 0);
    $tipo = trim($_POST['tipo'] ?? '');

    // 🔹 Validaciones básicas
    if ($nombre === '' || $descripcion === '' || $precio <= 0 || $categoria_id <= 0 || $tipo === '') {
        echo "<script>alert('⚠️ Todos los campos son obligatorios y deben ser válidos.'); window.location='panel.php';</script>";
        exit;
    }

    // ⚠️ Validar si se seleccionó una subcategoría (opcional según diseño)
    if ($subcategoria_id <= 0) {
        echo "<script>alert('⚠️ Debes seleccionar una subcategoría válida.'); window.location='panel.php';</script>";
        exit;
    }

    // 🔹 Validar y procesar imagen
    if (!isset($_FILES['imagen']) || $_FILES['imagen']['error'] !== UPLOAD_ERR_OK) {
        echo "<script>alert('⚠️ Debes seleccionar una imagen válida.'); window.location='panel.php';</script>";
        exit;
    }

    $nombreArchivo = basename($_FILES['imagen']['name']);
    $extension = strtolower(pathinfo($nombreArchivo, PATHINFO_EXTENSION));
    $extensionesPermitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

    if (!in_array($extension, $extensionesPermitidas)) {
        echo "<script>alert('❌ Formato de imagen no permitido. Solo JPG, PNG, GIF o WEBP.'); window.location='panel.php';</script>";
        exit;
    }

    // 🔹 Renombrar archivo de forma segura
    $nombreArchivoSeguro = time() . '_' . preg_replace('/[^a-zA-Z0-9_\.-]/', '_', $nombreArchivo);
    $rutaDestino = "../img/" . $nombreArchivoSeguro;

    if (!move_uploaded_file($_FILES['imagen']['tmp_name'], $rutaDestino)) {
        echo "<script>alert('❌ Error al subir la imagen.'); window.location='panel.php';</script>";
        exit;
    }

    // 🔹 Insertar en la base de datos
    $sql = "INSERT INTO productos (nombre, descripcion, precio, imagen, categoria_id, subcategoria_id, tipo)
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssdsiis", $nombre, $descripcion, $precio, $nombreArchivoSeguro, $categoria_id, $subcategoria_id, $tipo);

    if ($stmt->execute()) {
        echo "<script>alert('✅ Producto agregado correctamente.'); window.location='panel.php';</script>";
    } else {
        echo "<script>alert('❌ Error al agregar producto: " . $stmt->error . "'); window.location='panel.php';</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
