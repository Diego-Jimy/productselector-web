<?php
include '../conexion.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $entrada = trim($_POST['busqueda'] ?? ($_POST['id'] ?? ''));

    // ⚠️ Validación básica
    if (empty($entrada)) {
        echo "<script>alert('⚠️ Debes ingresar o seleccionar un producto para eliminar.'); window.location='panel.php';</script>";
        exit;
    }

    // 🔍 Buscar producto (por ID o nombre)
    if (ctype_digit($entrada)) {
        $stmt = $conn->prepare("SELECT id, imagen FROM productos WHERE id = ?");
        $stmt->bind_param("i", $entrada);
    } else {
        $stmt = $conn->prepare("SELECT id, imagen FROM productos WHERE nombre LIKE ?");
        $like = "%$entrada%";
        $stmt->bind_param("s", $like);
    }

    if (!$stmt->execute()) {
        echo "<script>alert('❌ Error al buscar el producto.'); window.location='panel.php';</script>";
        exit;
    }

    $result = $stmt->get_result();

    // 🚫 Sin resultados
    if ($result->num_rows === 0) {
        echo "<script>alert('⚠️ No se encontró ningún producto con ese nombre o ID.'); window.location='panel.php';</script>";
        exit;
    }

    // ⚠️ Múltiples coincidencias
    if ($result->num_rows > 1) {
        $ids = '';
        while ($row = $result->fetch_assoc()) {
            $ids .= "- ID: {$row['id']}\\n";
        }
        echo "<script>alert('⚠️ Se encontraron varios productos con ese nombre. Especifica el ID:\\n$ids'); window.location='panel.php';</script>";
        exit;
    }

    // ✅ Solo un resultado
    $producto = $result->fetch_assoc();
    $id = (int)$producto['id'];
    $imagen = $producto['imagen'] ?? null;

    $stmt->close();

    // 🗑️ Eliminar producto
    $delete = $conn->prepare("DELETE FROM productos WHERE id = ?");
    $delete->bind_param("i", $id);

    if ($delete->execute()) {
        // 🖼️ Eliminar imagen asociada (si existe)
        $rutaImagen = "../img/" . $imagen;
        if (!empty($imagen) && file_exists($rutaImagen)) {
            unlink($rutaImagen);
        }

        echo "<script>alert('✅ Producto eliminado correctamente.'); window.location='panel.php';</script>";
    } else {
        echo "<script>alert('❌ Error al eliminar el producto: " . addslashes($delete->error) . "'); window.location='panel.php';</script>";
    }

    $delete->close();
}

$conn->close();
?>
