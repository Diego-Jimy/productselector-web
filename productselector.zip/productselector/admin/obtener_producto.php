<?php
include '../conexion.php';
header('Content-Type: application/json; charset=utf-8');


if (empty($_GET['id']) || !ctype_digit($_GET['id'])) {
    echo json_encode(["success" => false, "error" => "ID inválido."], JSON_UNESCAPED_UNICODE);
    exit;
}

$id = (int) $_GET['id'];


$stmt = $conn->prepare("
    SELECT nombre, descripcion, precio, imagen, categoria_id, subcategoria_id
    FROM productos 
    WHERE id = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();


if ($result && $row = $result->fetch_assoc()) {
    echo json_encode([
        "success" => true,
        "nombre" => $row['nombre'],
        "descripcion" => $row['descripcion'],
        "precio" => $row['precio'],
        "imagen" => $row['imagen'],
        "categoria_id" => $row['categoria_id'],
        "subcategoria_id" => $row['subcategoria_id']
    ], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode([
        "success" => false,
        "error" => "Producto no encontrado."
    ], JSON_UNESCAPED_UNICODE);
}


$stmt->close();
$conn->close();
?>
