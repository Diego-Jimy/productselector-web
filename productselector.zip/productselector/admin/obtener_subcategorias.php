<?php
include '../conexion.php';
header('Content-Type: application/json; charset=utf-8');


if (empty($_GET['categoria_id']) || !ctype_digit($_GET['categoria_id'])) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "error" => "⚠️ ID de categoría no válido o faltante."
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$categoria_id = (int) $_GET['categoria_id'];


$stmt = $conn->prepare("SELECT id, nombre FROM subcategorias WHERE categoria_id = ? ORDER BY nombre ASC");
if (!$stmt) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "error" => "❌ Error interno al preparar la consulta."
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$stmt->bind_param("i", $categoria_id);
$stmt->execute();
$result = $stmt->get_result();


if ($result && $result->num_rows > 0) {
    $subcategorias = [];
    while ($row = $result->fetch_assoc()) {
        $subcategorias[] = [
            "id" => (int)$row['id'],
            "nombre" => htmlspecialchars($row['nombre'], ENT_QUOTES, 'UTF-8')
        ];
    }

    echo json_encode([
        "success" => true,
        "subcategorias" => $subcategorias
    ], JSON_UNESCAPED_UNICODE);
} else {
  
    echo json_encode([
        "success" => true,
        "subcategorias" => []
    ], JSON_UNESCAPED_UNICODE);
}


$stmt->close();
$conn->close();
?>
