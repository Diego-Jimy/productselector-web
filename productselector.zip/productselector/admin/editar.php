<?php
include '../conexion.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = intval($_POST['id'] ?? 0);
    $nombre = trim($_POST['nombre'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $precio = floatval($_POST['precio'] ?? 0);
    $categoria_id = intval($_POST['categoria_id'] ?? 0);
    $subcategoria_id = intval($_POST['subcategoria_id'] ?? 0);
    $imagen = null;

   
    if ($id <= 0) {
        echo "<script>alert('⚠️ ID del producto inválido.'); window.location='panel.php';</script>";
        exit;
    }

    
    $check = $conn->prepare("SELECT imagen FROM productos WHERE id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    $check->store_result();

    if ($check->num_rows === 0) {
        echo "<script>alert('⚠️ El producto no existe.'); window.location='panel.php';</script>";
        $check->close();
        $conn->close();
        exit;
    }

    $check->bind_result($imagenActual);
    $check->fetch();
    $check->close();

    
    if (!empty($_FILES['imagen']['name'])) {
        $nombreArchivo = basename($_FILES['imagen']['name']);
        $extension = strtolower(pathinfo($nombreArchivo, PATHINFO_EXTENSION));
        $permitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        if (!in_array($extension, $permitidas)) {
            echo "<script>alert('❌ Formato no permitido. Usa JPG, PNG, GIF o WEBP.'); window.location='panel.php';</script>";
            exit;
        }

        $nombreArchivoSeguro = time() . '_' . preg_replace('/[^a-zA-Z0-9_\.-]/', '_', $nombreArchivo);
        $rutaDestino = "../img/" . $nombreArchivoSeguro;

        
        if ($imagenActual && file_exists("../img/$imagenActual")) {
            unlink("../img/$imagenActual");
        }

        if (!move_uploaded_file($_FILES['imagen']['tmp_name'], $rutaDestino)) {
            echo "<script>alert('❌ Error al subir la nueva imagen.'); window.location='panel.php';</script>";
            exit;
        }

        $imagen = $nombreArchivoSeguro;
    }

    
    $campos = [];
    $tipos = '';
    $valores = [];

    if ($nombre !== '') { $campos[] = "nombre=?"; $tipos .= "s"; $valores[] = $nombre; }
    if ($descripcion !== '') { $campos[] = "descripcion=?"; $tipos .= "s"; $valores[] = $descripcion; }
    if ($precio > 0) { $campos[] = "precio=?"; $tipos .= "d"; $valores[] = $precio; }
    if ($categoria_id > 0) { $campos[] = "categoria_id=?"; $tipos .= "i"; $valores[] = $categoria_id; }
    if ($subcategoria_id > 0) { $campos[] = "subcategoria_id=?"; $tipos .= "i"; $valores[] = $subcategoria_id; }
    if ($imagen) { $campos[] = "imagen=?"; $tipos .= "s"; $valores[] = $imagen; }

    if (empty($campos)) {
        echo "<script>alert('⚠️ No hay datos nuevos para actualizar.'); window.location='panel.php';</script>";
        exit;
    }

    
    $sql = "UPDATE productos SET " . implode(", ", $campos) . " WHERE id=?";
    $tipos .= "i";
    $valores[] = $id;

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($tipos, ...$valores);

    if ($stmt->execute()) {
        echo "<script>alert('✅ Producto actualizado correctamente.'); window.location='panel.php';</script>";
    } else {
        echo "<script>alert('❌ Error al actualizar producto: " . $stmt->error . "'); window.location='panel.php';</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
