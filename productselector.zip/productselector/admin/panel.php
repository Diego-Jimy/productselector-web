<?php include '../login/proteger.php'; ?>
<?php include '../conexion.php'; ?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>⚙️ Panel de Administración - PC | TecShop</title>
  <link rel="stylesheet" href="admin.css?v=<?php echo time(); ?>">

</head>

<body class="admin-body">
  <header class="admin-header">
    <div class="admin-header-left">
      <h1>⚙️ Panel de Administración - PC</h1>
    </div>

    <div class="admin-header-right">
      <span class="admin-user"> 
      <a class="admin-volver" href="../pc.html">⬅ Volver a Componentes</a>
    </div>
  </header>

  <main class="admin-main">
    <div class="acciones-principales">
      <button class="btn-accion" onclick="mostrarSeccion('agregar')">➕ Agregar</button>
      <button class="btn-accion editar" onclick="mostrarSeccion('editar')">✏️ Editar</button>
      <button class="btn-accion eliminar" onclick="mostrarSeccion('eliminar')">🗑️ Eliminar</button>
    </div>

    <!-- ================= AGREGAR ================= -->
    <section id="agregar" class="panel-section oculto">
      <h2>Agregar nuevo componente (PC)</h2>
      <form action="agregar.php" method="POST" enctype="multipart/form-data">
        <label>Nombre del producto:</label>
        <input type="text" name="nombre" required placeholder="Ej: Intel Core i5-12400">

        <label>Descripción:</label>
        <textarea name="descripcion" required placeholder="Breve descripción del producto..."></textarea>

        <label>Precio (S/):</label>
        <input type="number" step="0.01" name="precio" required placeholder="Ej: 749.90">

        <label>Seleccionar imagen:</label>
        <input type="file" name="imagen" accept="image/*" required>

        <label>Categoría:</label>
        <select name="categoria_id" id="categoria" required>
          <option value="">-- Selecciona una categoría --</option>
          <?php
          $cats = $conn->query("SELECT id, nombre FROM categorias ORDER BY nombre ASC");
          while ($c = $cats->fetch_assoc()) {
              echo "<option value='{$c['id']}'>" . htmlspecialchars($c['nombre']) . "</option>";
          }
          ?>
        </select>

        <label>Subcategoría:</label>
        <select name="subcategoria_id" id="subcategoria" required>
          <option value="">-- Primero selecciona una categoría --</option>
        </select>

        <input type="hidden" name="tipo" value="pc">
        <button type="submit" class="btn-agregar">✅ Agregar Producto</button>
      </form>
    </section>

    <!-- ================= EDITAR ================= -->
    <section id="editar" class="panel-section oculto">
      <h2>Editar componente existente</h2>
      <form id="form-editar" action="editar.php" method="POST" enctype="multipart/form-data">
        <label>Seleccione el producto:</label>
        <select name="id" id="productoSelect" required>
          <option value="">-- Selecciona un producto --</option>
          <?php
          $productos = $conn->query("SELECT id, nombre FROM productos WHERE tipo='pc' ORDER BY nombre ASC");
          while ($p = $productos->fetch_assoc()) {
              echo "<option value='{$p['id']}'>" . htmlspecialchars($p['nombre']) . "</option>";
          }
          ?>
        </select>

        <div id="datos-edicion" style="display:none;">
          <label>Nombre actual:</label>
          <input type="text" name="nombre" id="nombre">

          <label>Descripción:</label>
          <textarea name="descripcion" id="descripcion"></textarea>

          <label>Precio (S/):</label>
          <input type="number" step="0.01" name="precio" id="precio">

          <label>Categoría:</label>
          <select name="categoria_id" id="categoriaEditar">
            <option value="">-- Selecciona una categoría --</option>
            <?php
            $cats = $conn->query("SELECT id, nombre FROM categorias ORDER BY nombre ASC");
            while ($c = $cats->fetch_assoc()) {
                echo "<option value='{$c['id']}'>" . htmlspecialchars($c['nombre']) . "</option>";
            }
            ?>
          </select>

          <label>Subcategoría:</label>
          <select name="subcategoria_id" id="subcategoriaEditar">
            <option value="">-- Primero selecciona una categoría --</option>
          </select>

          <label>Imagen actual:</label><br>
          <img id="imagen-actual" src="" alt="Imagen del producto" style="max-width:120px; border-radius:6px; border:2px solid #ccc;"><br>

          <label>Reemplazar imagen (opcional):</label>
          <input type="file" name="imagen" accept="image/*">

          <button type="submit" class="btn-editar">💾 Guardar Cambios</button>
        </div>
      </form>
    </section>

    <!-- ================= ELIMINAR ================= -->
    <section id="eliminar" class="panel-section oculto">
      <h2>Eliminar un componente</h2>
      <form action="eliminar.php" method="POST" onsubmit="return confirmarEliminacion()">
        <label>Selecciona el producto a eliminar:</label>
        <select name="id" required>
          <option value="">-- Selecciona un producto --</option>
          <?php
          $productos = $conn->query("SELECT id, nombre FROM productos ORDER BY nombre ASC");
          while ($p = $productos->fetch_assoc()) {
              echo "<option value='{$p['id']}'>" . htmlspecialchars($p['nombre']) . "</option>";
          }
          ?>
        </select>
        <button type="submit" class="btn-eliminar">🗑️ Eliminar Producto</button>
      </form>
    </section>

    <!-- ================= CERRAR SESIÓN ================= -->
    <div class="logout-section">
      
      <a href="../login/logout.php" class="logout-btn">🚪 Cerrar sesión</a>
    </div>
  </main>

  <footer class="admin-footer">
    <p>&copy; <?= date('Y') ?> TecShop — Panel de administración (PC)</p>
  </footer>

  <script>
    function mostrarSeccion(id) {
      document.querySelectorAll('.panel-section').forEach(s => s.classList.add('oculto'));
      document.getElementById(id).classList.remove('oculto');
    }

    function confirmarEliminacion() {
      return confirm("¿Seguro que deseas eliminar este producto? Esta acción no se puede deshacer.");
    }

    document.getElementById('categoria')?.addEventListener('change', async function() {
      const categoriaId = this.value;
      const subSelect = document.getElementById('subcategoria');

      if (!categoriaId) {
        subSelect.innerHTML = "<option value=''>-- Primero selecciona una categoría --</option>";
        return;
      }

      try {
        const response = await fetch('obtener_subcategorias.php?categoria_id=' + categoriaId);
        const data = await response.json();

        if (data.success) {
          subSelect.innerHTML = "<option value=''>-- Selecciona una subcategoría --</option>";
          data.subcategorias.forEach(sub => {
            subSelect.innerHTML += `<option value='${sub.id}'>${sub.nombre}</option>`;
          });
        } else {
          subSelect.innerHTML = "<option value=''>-- No hay subcategorías disponibles --</option>";
        }
      } catch (e) {
        console.error("Error al cargar subcategorías:", e);
        subSelect.innerHTML = "<option value=''>❌ Error al cargar</option>";
      }
    });

    document.getElementById('categoriaEditar')?.addEventListener('change', async function() {
      const categoriaId = this.value;
      const subSelect = document.getElementById('subcategoriaEditar');

      if (!categoriaId) {
        subSelect.innerHTML = "<option value=''>-- Primero selecciona una categoría --</option>";
        return;
      }

      try {
        const response = await fetch('obtener_subcategorias.php?categoria_id=' + categoriaId);
        const data = await response.json();

        if (data.success) {
          subSelect.innerHTML = "<option value=''>-- Selecciona una subcategoría --</option>";
          data.subcategorias.forEach(sub => {
            subSelect.innerHTML += `<option value='${sub.id}'>${sub.nombre}</option>`;
          });
        } else {
          subSelect.innerHTML = "<option value=''>-- No hay subcategorías disponibles --</option>";
        }
      } catch (e) {
        console.error("Error al cargar subcategorías:", e);
        subSelect.innerHTML = "<option value=''>❌ Error al cargar</option>";
      }
    });

    const select = document.getElementById('productoSelect');
    const datos = document.getElementById('datos-edicion');
    const imgActual = document.getElementById('imagen-actual');

    select?.addEventListener('change', async () => {
      const id = select.value;
      if (!id) {
        datos.style.display = "none";
        return;
      }

      try {
        const res = await fetch('obtener_producto.php?id=' + id);
        const data = await res.json();

        if (data.success) {
          document.getElementById('nombre').value = data.nombre || '';
          document.getElementById('descripcion').value = data.descripcion || '';
          document.getElementById('precio').value = data.precio || '';
          document.getElementById('categoriaEditar').value = data.categoria_id || '';
          imgActual.src = data.imagen ? '../img/' + data.imagen : '../img/no-image.png';
          datos.style.display = "block";

          if (data.categoria_id) {
            const response = await fetch('obtener_subcategorias.php?categoria_id=' + data.categoria_id);
            const subs = await response.json();
            const subSelect = document.getElementById('subcategoriaEditar');
            subSelect.innerHTML = "<option value=''>-- Selecciona una subcategoría --</option>";
            if (subs.success) {
              subs.subcategorias.forEach(sub => {
                subSelect.innerHTML += `<option value='${sub.id}' ${sub.id == data.subcategoria_id ? 'selected' : ''}>${sub.nombre}</option>`;
              });
            }
          }
        } else {
          alert("⚠️ No se pudo cargar la información del producto.");
        }
      } catch (e) {
        console.error(e);
        alert("❌ Error al conectar con el servidor.");
      }
    });
  </script>
</body>
</html>
