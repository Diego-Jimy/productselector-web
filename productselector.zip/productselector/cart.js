let cart = JSON.parse(localStorage.getItem('cart')) || [];

function addToCart(name, price) {
    if (!name || typeof price !== 'number' || price < 0) return;
    const existing = cart.find(item => item.name === name);
    if (existing) {
        existing.qty += 1;
    } else {
        cart.push({ name, price, qty: 1 });
    }
    saveCart();
    showNotification(`${name} añadido al carrito.`);
    updateCartPanel();
}

function saveCart() {
    try {
        localStorage.setItem('cart', JSON.stringify(cart));
    } catch (e) {
        console.error('Error al guardar en localStorage:', e);
    }
}

function showNotification(message) {
    const notification = document.createElement('div');
    notification.textContent = message;
    notification.style.cssText = 'position: fixed; top: 20px; right: 20px; background: rgba(15, 106, 145, 0.9); color: white; padding: 12px 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.2); z-index: 1001; animation: fadeInOut 3s ease-out forwards;';
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
}

function toggleCart() {
    const cartPanel = document.querySelector('.cart-panel');
    if (cartPanel) {
        cartPanel.classList.toggle('active');
        updateCartPanel();
    }
}

function closeCart() {
    const cartPanel = document.querySelector('.cart-panel');
    if (cartPanel) cartPanel.classList.remove('active');
}

function clearCart() {
    if (confirm('¿Vaciar el carrito?')) {
        cart = [];
        saveCart();
        updateCartPanel();
    }
}

function updateCartPanel() {
    const cartPanel = document.querySelector('.cart-panel');
    if (!cartPanel) return;
    cartPanel.innerHTML = `
        <div class="cart-header">
            <h3>Carrito</h3>
            <button class="cart-close" onclick="closeCart()">×</button>
        </div>
        <div class="cart-items">
            ${cart.length === 0 ? '<p class="empty-cart">El carrito está vacío.</p>' : ''}
            ${cart.map((item, index) => `
                <div class="cart-item">
                    <span>${item.name} (x${item.qty}) - S/ ${(item.price * item.qty).toFixed(2)}</span>
                    <button class="remove-btn" onclick="removeFromCart(${index}, this)">×</button>
                </div>
            `).join('')}
        </div>
        ${cart.length > 0 ? `
            <div class="cart-footer">
                <p><strong>Total: S/ ${cart.reduce((sum, i) => sum + i.price * i.qty, 0).toFixed(2)}</strong></p>
                <button class="clear-btn" onclick="clearCart()">Vaciar Carrito</button>
               
            </div>
        ` : ''}
    `;
}

function removeFromCart(index, button) {
    if (confirm('¿Eliminar este ítem?')) {
        cart.splice(index, 1);
        saveCart();
        updateCartPanel();
        if (button && button.closest('.cart-item')) button.closest('.cart-item').remove();
    }
}

function checkout() {
    if (cart.length === 0) {
        alert("Tu carrito está vacío.");
        return;
    }
    const total = cart.reduce((sum, i) => sum + i.price * i.qty, 0).toFixed(2);
    alert("Tu compra ha sido registrada. Total: S/ " + total);
    clearCart();
}

window.onload = function() {
    const cartIcon = document.querySelector('.cart-icon');
    if (cartIcon && !cartIcon.onclick) {
        cartIcon.onclick = toggleCart;
        updateCartPanel();
    }
};

window.addEventListener('storage', (event) => {
    if (event.key === 'cart') {
        cart = JSON.parse(event.newValue) || [];
        updateCartPanel();
    }
});     actualizalo  