<?php
session_start();
include '../conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $usuario = trim($_POST['usuario']);
  $contrasena = trim($_POST['contrasena']);

  $stmt = $conn->prepare("SELECT * FROM administradores WHERE usuario = ?");
  $stmt->bind_param("s", $usuario);
  $stmt->execute();
  $result = $stmt->get_result();

  if ($result && $result->num_rows === 1) {
    $admin = $result->fetch_assoc();
    if (hash('sha256', $contrasena) === $admin['contrasena']) {
      $_SESSION['admin'] = $admin['usuario'];
      header("Location: ../admin/panel.php");
      exit;
    } else {
      $error = "❌ Contraseña incorrecta.";
    }
  } else {
    $error = "⚠️ Usuario no encontrado.";
  }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Acceso Administrador - TecShop</title>
   
  <link rel="stylesheet" href="login.css">
</head>
<body class="login-body">
  <div class="login-container">
    <h1>🔐 Acceso Administrador</h1>
    <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
    <form method="POST">
      <label>Usuario:</label>
      <input type="text" name="usuario" required>

      <label>Contraseña:</label>
      <input type="password" name="contrasena" required>

      <button type="submit">Iniciar sesión</button>
    </form>
  </div>
</body>
</html>
