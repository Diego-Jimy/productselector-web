<?php include '../login/proteger.php'; ?>
<?php include '../conexion.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title> Panel de Administración - Laptops | TecShop</title>
  <link rel="stylesheet" href="admin_laptop.css"/>
</head>

<body class="admin-body">
<header class="admin-header">
  <h1> Panel de Administración - Laptops</h1>
  <div class="admin-links">
    <a class="admin-volver" href="../carreras.html">⬅ Volver a Carreras</a>
    <a href="programas/panel_programa.php" class="admin-btn izquierda" title="Panel de Programas">🧩</a>
    <a href="ventas/panel_ventas.php" class="admin-btn derecha" title="Panel de Ventas">📊</a>
  </div>
</header>

<main class="admin-main">
  
  <div class="acciones-principales">
    <button class="btn-accion" onclick="mostrarSeccion('agregar')">➕ Agregar</button>
    <button class="btn-accion editar" onclick="mostrarSeccion('editar')">✏️ Editar</button>
    <button class="btn-accion eliminar" onclick="mostrarSeccion('eliminar')">🗑️ Eliminar</button>
  </div>

  
  <section id="agregar" class="panel-section oculto">
    <h2>➕ Agregar nueva Laptop</h2>
    <form action="guardar_laptop.php" method="POST" enctype="multipart/form-data" class="admin-form">

      <label>Serie (Código único):</label>
      <input type="text" name="serie" required placeholder="Ej: LAP123">

      <label>Nombre:</label>
      <input type="text" name="nombre" required placeholder="Ej: Lenovo IdeaPad 3">

      <label>Tipo:</label>
      <input type="text" name="tipo" value="laptop" readonly>

      <label>Procesador:</label>
      <select name="procesador_id" required>
        <option value="">-- Selecciona --</option>
        <?php
        $procesadores = $conn->query("SELECT id, nombre FROM procesadores ORDER BY nombre ASC");
        while ($p = $procesadores->fetch_assoc()) {
          echo "<option value='{$p['id']}'>" . htmlspecialchars($p['nombre']) . "</option>";
        }
        ?>
      </select>

      <label>Precio (S/):</label>
      <input type="number" step="0.01" name="precio" required placeholder="Ej: 3599.00">

      <h3> Detalles técnicos</h3>
      <label>Marca:</label><input type="text" name="marca" placeholder="Ej: Lenovo">
      <label>Memoria RAM:</label><input type="text" name="ram" placeholder="Ej: 16GB DDR4">
      <label>Almacenamiento:</label><input type="text" name="almacenamiento" placeholder="Ej: 512GB SSD">
      <label>Pantalla:</label><input type="text" name="pantalla" placeholder="Ej: 15.6'' FHD">
      <label>Sistema Operativo:</label><input type="text" name="so" placeholder="Ej: Windows 11 Home">
      <label>Batería:</label><input type="text" name="bateria" placeholder="Ej: 8 horas">
      <label>Descripción:</label><textarea name="descripcion" rows="3" placeholder="Especificaciones adicionales..."></textarea>

      <h3>📸 Imágenes de la Laptop</h3>
      <div class="imagenes-grid">
        <div>
          <label>Imagen principal:</label>
          <input type="file" name="imagen" accept="image/*">
        </div>
        <div>
          <label>Imagen abierta:</label>
          <input type="file" name="imagen_abierta" accept="image/*">
        </div>
        <div>
          <label>Imagen cerrada:</label>
          <input type="file" name="imagen_cerrada" accept="image/*">
        </div>
        <div>
          <label>Imagen interna:</label>
          <input type="file" name="imagen_interna" accept="image/*">
        </div>
      </div>

      <h3>🎓 Carreras compatibles</h3>
      <div class="checkbox-group">
        <?php
        $carreras = $conn->query("SELECT id, nombre FROM carreras ORDER BY nombre ASC");
        while ($c = $carreras->fetch_assoc()) {
          echo "
          <div class='checkbox-item'>
            <input type='checkbox' name='carreras[]' id='car-{$c['id']}' value='{$c['id']}'>
            <label for='car-{$c['id']}'>" . htmlspecialchars($c['nombre']) . "</label>
          </div>";
        }
        ?>
      </div>

      <h3>🖥️ Programas compatibles</h3>
      <div class="checkbox-group">
        <?php
        $programas = $conn->query("SELECT id, nombre FROM programas ORDER BY nombre ASC");
        while ($pr = $programas->fetch_assoc()) {
          echo "
          <div class='checkbox-item'>
            <input type='checkbox' name='programas[]' id='prog-{$pr['id']}' value='{$pr['id']}'>
            <label for='prog-{$pr['id']}'>" . htmlspecialchars($pr['nombre']) . "</label>
          </div>";
        }
        ?>
      </div>

      <button type="submit" class="btn-agregar">💾 Guardar Laptop</button>
    </form>
  </section>

 
  <section id="editar" class="panel-section oculto">
    <h2>✏️ Editar Laptop existente</h2>
    <form action="buscar_laptop.php" method="POST" class="admin-form">
      <label>Serie de la laptop:</label>
      <input type="text" name="serie" required placeholder="Ej: LAP123">
      <button type="submit" class="btn-editar">🔍 Buscar</button>
    </form>
  </section>

  
  <section id="eliminar" class="panel-section oculto">
    <h2>🗑️ Eliminar Laptop</h2>
    <form action="buscar_eliminar.php" method="POST" class="admin-form">
      <label>Serie de la laptop:</label>
      <input type="text" name="serie" required placeholder="Ej: LAP123">
      <button type="submit" class="btn-eliminar">🗑️ Buscar y eliminar</button>
    </form>
  </section>
</main>

<footer class="admin-footer">
  <p>&copy; <?= date('Y') ?> TecShop. Todos los derechos reservados.</p>
</footer>

<script>

function mostrarSeccion(id) {
  document.querySelectorAll('.panel-section').forEach(s => s.classList.add('oculto'));
  document.getElementById(id).classList.remove('oculto');
}
</script>
</body>
</html>
