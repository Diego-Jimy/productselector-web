<?php
include '../conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $serie = trim($_POST['serie']);
    $nombre = trim($_POST['nombre']);
    $tipo = trim($_POST['tipo']);
    $procesador_id = intval($_POST['procesador_id']);
    $precio = floatval($_POST['precio']);
    $marca = trim($_POST['marca']);
    $ram = trim($_POST['ram']);
    $almacenamiento = trim($_POST['almacenamiento']);
    $pantalla = trim($_POST['pantalla']);
    $so = trim($_POST['so']);
    $bateria = trim($_POST['bateria']);
    $descripcion = trim($_POST['descripcion']);
    $carreras = isset($_POST['carreras']) ? $_POST['carreras'] : [];
    $programas = isset($_POST['programas']) ? $_POST['programas'] : [];

    if (empty($serie) || empty($nombre) || empty($tipo) || !$procesador_id || $precio <= 0) {
        echo "<script>alert('⚠️ Todos los campos obligatorios deben completarse.'); window.location='panel_laptop.php';</script>";
        exit;
    }

    $check = $conn->prepare("SELECT id FROM laptops WHERE serie = ?");
    $check->bind_param("s", $serie);
    $check->execute();
    $check->store_result();
    if ($check->num_rows > 0) {
        echo "<script>alert('❌ Esa serie ya existe. Usa otra.'); window.location='panel_laptop.php';</script>";
        $check->close();
        exit;
    }
    $check->close();

    $nombreArchivo = "laptop.png";
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        $tipoArchivo = mime_content_type($_FILES['imagen']['tmp_name']);
        if (strpos($tipoArchivo, 'image/') === 0) {
            if ($_FILES['imagen']['size'] > 2 * 1024 * 1024) {
                echo "<script>alert('⚠️ La imagen principal no debe superar los 2 MB.'); window.location='panel_laptop.php';</script>";
                exit;
            }
            $nombreArchivo = time() . "_" . basename($_FILES['imagen']['name']);
            $rutaDestino = "../img/laptops/" . $nombreArchivo;
            move_uploaded_file($_FILES['imagen']['tmp_name'], $rutaDestino);
        }
    }

    $stmt = $conn->prepare("INSERT INTO laptops (serie, nombre, tipo, procesador_id, precio, imagen)
                            VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssids", $serie, $nombre, $tipo, $procesador_id, $precio, $nombreArchivo);

    if ($stmt->execute()) {
        $laptop_id = $conn->insert_id;

        $stmt2 = $conn->prepare("UPDATE detalles 
                                 SET marca=?, ram=?, almacenamiento=?, pantalla=?, sistema_operativo=?, bateria=?, descripcion=? 
                                 WHERE laptop_id=?");
        $stmt2->bind_param("sssssssi", $marca, $ram, $almacenamiento, $pantalla, $so, $bateria, $descripcion, $laptop_id);
        $stmt2->execute();
        $stmt2->close();

        if (!empty($carreras)) {
            $stmt3 = $conn->prepare("INSERT INTO laptop_carreras (laptop_id, carrera_id) VALUES (?, ?)");
            foreach ($carreras as $carrera_id) {
                $idCarrera = intval($carrera_id);
                $stmt3->bind_param("ii", $laptop_id, $idCarrera);
                $stmt3->execute();
            }
            $stmt3->close();
        }

        if (!empty($programas)) {
            $stmt4 = $conn->prepare("INSERT INTO laptop_programa (laptop_id, programa_id) VALUES (?, ?)");
            foreach ($programas as $programa_id) {
                $idPrograma = intval($programa_id);
                $stmt4->bind_param("ii", $laptop_id, $idPrograma);
                $stmt4->execute();
            }
            $stmt4->close();
        }

        
        $imagenesExtras = [
            'imagen_abierta' => 'abierta',
            'imagen_cerrada' => 'cerrada',
            'imagen_interna' => 'interna'
        ];

        $stmtImg = $conn->prepare("INSERT INTO laptop_imagenes (laptop_id, imagen, tipo) VALUES (?, ?, ?)");
        foreach ($imagenesExtras as $campo => $tipoImg) {
            if (isset($_FILES[$campo]) && $_FILES[$campo]['error'] === UPLOAD_ERR_OK) {
                $tipoArchivo = mime_content_type($_FILES[$campo]['tmp_name']);
                if (strpos($tipoArchivo, 'image/') === 0 && $_FILES[$campo]['size'] <= 2 * 1024 * 1024) {
                    $nombreExtra = time() . "_" . basename($_FILES[$campo]['name']);
                    $rutaExtra = "../img/laptops/" . $nombreExtra;
                    move_uploaded_file($_FILES[$campo]['tmp_name'], $rutaExtra);
                    $stmtImg->bind_param("iss", $laptop_id, $nombreExtra, $tipoImg);
                    $stmtImg->execute();
                }
            }
        }
        $stmtImg->close();

        echo "<script>alert('✅ Laptop agregada correctamente con sus imágenes, detalles, carreras y programas.'); window.location='panel_laptop.php';</script>";
    } else {
        echo "<script>alert('❌ Error al guardar: " . htmlspecialchars($stmt->error) . "'); window.location='panel_laptop.php';</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
