<?php
include '../conexion.php';


if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: panel_laptop.php");
    exit;
}

$serie = trim($_POST['serie']);


$sql = "SELECT l.*, p.nombre AS procesador, d.marca, d.ram, d.almacenamiento, 
               d.pantalla, d.sistema_operativo, d.bateria
        FROM laptops l
        LEFT JOIN procesadores p ON l.procesador_id = p.id
        LEFT JOIN detalles d ON l.id = d.laptop_id
        WHERE l.serie = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $serie);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<script>alert('❌ No se encontró ninguna laptop con esa serie.'); window.location='panel_laptop.php';</script>";
    exit;
}

$laptop = $result->fetch_assoc();
$laptop_id = $laptop['id'];

$imagenes = [];
$sqlImg = $conn->prepare("SELECT tipo, imagen FROM laptop_imagenes WHERE laptop_id = ?");
$sqlImg->bind_param("i", $laptop_id);
$sqlImg->execute();
$resImg = $sqlImg->get_result();
while ($img = $resImg->fetch_assoc()) {
    $imagenes[$img['tipo']] = $img['imagen'];
}
$sqlImg->close();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>🗑️ Confirmar Eliminación | TecShop</title>
  <link rel="stylesheet" href="admin_laptop.css">
</head>

<body class="admin-body">
  <header class="admin-header">
    <h1>🗑️ Confirmar Eliminación</h1>
    <a class="admin-volver" href="panel_laptop.php">⬅ Volver al Panel</a>
  </header>

  <main class="admin-main">
    <div class="admin-card">
      <h2><?= htmlspecialchars($laptop['nombre']) ?></h2>

      <?php
      $ruta_img = "../img/laptops/" . htmlspecialchars($laptop['imagen']);
      if (!empty($laptop['imagen']) && file_exists($ruta_img)) {
          echo "<p><strong>Imagen principal:</strong></p><img src='{$ruta_img}' width='200' alt='Laptop principal'>";
      } else {
          echo "<p><em>Sin imagen principal</em></p>";
      }

      foreach (['abierta', 'cerrada', 'interna'] as $tipo) {
          if (!empty($imagenes[$tipo])) {
              $ruta = "../img/laptops/" . htmlspecialchars($imagenes[$tipo]);
              if (file_exists($ruta)) {
                  echo "<p><strong>Vista {$tipo}:</strong></p><img src='{$ruta}' width='200' alt='{$tipo}'>";
              }
          }
      }
      ?>

      <p><strong>Serie:</strong> <?= htmlspecialchars($laptop['serie']) ?></p>
      <p><strong>Procesador:</strong> <?= htmlspecialchars($laptop['procesador']) ?></p>
      <p><strong>RAM:</strong> <?= htmlspecialchars($laptop['ram']) ?></p>
      <p><strong>Almacenamiento:</strong> <?= htmlspecialchars($laptop['almacenamiento']) ?></p>
      <p><strong>Pantalla:</strong> <?= htmlspecialchars($laptop['pantalla']) ?></p>
      <p><strong>Sistema Operativo:</strong> <?= htmlspecialchars($laptop['sistema_operativo']) ?></p>
      <p><strong>Batería:</strong> <?= htmlspecialchars($laptop['bateria']) ?></p>
      <p><strong>Precio:</strong> S/ <?= number_format($laptop['precio'], 2) ?></p>
    </div>

    <form action="laptop_eliminar.php" method="POST" onsubmit="return confirmarEliminacion();">
      <input type="hidden" name="id" value="<?= htmlspecialchars($laptop_id) ?>">
      <input type="hidden" name="serie" value="<?= htmlspecialchars($laptop['serie']) ?>">
      <button type="submit" class="btn-eliminar">✅ Confirmar Eliminación</button>
    </form>
  </main>

  <footer class="admin-footer">
    <p>&copy; <?= date('Y') ?> TecShop. Todos los derechos reservados.</p>
  </footer>

  <script>
    function confirmarEliminacion() {
      return confirm("⚠️ ¿Estás seguro de eliminar esta laptop y todas sus imágenes? Esta acción no se puede deshacer.");
    }
  </script>
</body>
</html>
