<?php
include '../../conexion.php';

// ✅ Validar ID de laptop
$laptop_id = isset($_GET['laptop_id']) ? intval($_GET['laptop_id']) : 0;

if ($laptop_id <= 0) {
  echo json_encode([]);
  exit;
}

// ✅ Consultar las ventas mensuales de esa laptop
$sql = "SELECT enero, febrero, marzo, abril, mayo, junio,
               julio, agosto, septiembre, octubre, noviembre, diciembre
        FROM ventas WHERE laptop_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $laptop_id);
$stmt->execute();
$result = $stmt->get_result();

if ($fila = $result->fetch_assoc()) {
  echo json_encode($fila);
} else {
  echo json_encode([]);
}

$stmt->close();
$conn->close();
?>
