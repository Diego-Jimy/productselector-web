<?php
include '../../conexion.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>📊 Panel de Ventas | TecShop</title>
  <link rel="stylesheet" href="../admin_laptop.css"/>
  <link rel="stylesheet" href="ventas.css"/>
</head>

<body class="admin-body">
  <header class="admin-header">
    <h1>📊 Panel de Administración - Ventas</h1>
    <a class="admin-volver" href="../panel_laptop.php">⬅ Volver al Panel de Laptops</a>
  </header>

  <main class="admin-main">

    <!-- BOTONES PRINCIPALES -->
    <div class="acciones-principales">
      <button class="btn-accion" onclick="mostrarSeccion('agregar')">➕ Agregar</button>
      <button class="btn-accion editar" onclick="mostrarSeccion('editar')">✏️ Editar</button>
    </div>

    <!-- ===================== AGREGAR ===================== -->
    <section id="agregar" class="panel-section oculto">
      <h2>Agregar Ventas Anuales</h2>
      <form action="guardar_venta.php" method="POST" class="admin-form">
        <label>Laptop:</label>
        <select name="laptop_id" required>
          <option value="">-- Selecciona una laptop --</option>
          <?php
          $laptops = $conn->query("SELECT id, nombre FROM laptops ORDER BY nombre ASC");
          while ($l = $laptops->fetch_assoc()) {
            echo "<option value='{$l['id']}'>" . htmlspecialchars($l['nombre']) . "</option>";
          }
          ?>
        </select>

        <h3>📅 Ventas por Mes (%)</h3>
        <div class="tabla-meses">
          <?php
          $meses = [
            "enero","febrero","marzo","abril","mayo","junio",
            "julio","agosto","septiembre","octubre","noviembre","diciembre"
          ];
          foreach ($meses as $mes) {
            echo "
              <div class='fila-mes'>
                <label>" . ucfirst($mes) . ":</label>
                <input type='number' name='$mes' min='0' max='100' placeholder='%' required>
              </div>
            ";
          }
          ?>
        </div>

        <button type="submit" class="btn-agregar">✅ Guardar Ventas</button>
      </form>
    </section>

    <!-- ===================== EDITAR ===================== -->
    <section id="editar" class="panel-section oculto">
      <h2>Editar Ventas Registradas</h2>
      <form action="editar_venta.php" method="POST" class="admin-form">
        <label>Selecciona Laptop:</label>
        <select name="laptop_id" id="laptopSelect" required onchange="cargarVentas()">
          <option value="">-- Selecciona una laptop --</option>
          <?php
          $laptops = $conn->query("SELECT id, nombre FROM laptops ORDER BY nombre ASC");
          while ($l = $laptops->fetch_assoc()) {
            echo "<option value='{$l['id']}'>" . htmlspecialchars($l['nombre']) . "</option>";
          }
          ?>
        </select>

        <div id="ventasMeses" style="margin-top:20px;">
          <p>Selecciona una laptop para editar sus ventas mensuales.</p>
        </div>

        <button type="submit" class="btn-editar oculto" id="btnActualizar">✏️ Actualizar Ventas</button>
      </form>
    </section>

    <script>
    function cargarVentas() {
      const id = document.getElementById('laptopSelect').value;
      const contenedor = document.getElementById('ventasMeses');
      const boton = document.getElementById('btnActualizar');

      if (!id) {
        contenedor.innerHTML = "<p>Selecciona una laptop para ver sus ventas.</p>";
        boton.classList.add('oculto');
        return;
      }

      fetch('obtener_ventas.php?laptop_id=' + id)
        .then(res => res.json())
        .then(data => {
          if (!data || Object.keys(data).length === 0) {
            contenedor.innerHTML = "<p>No hay ventas registradas para esta laptop.</p>";
            boton.classList.add('oculto');
          } else {
            let html = '<div class="tabla-meses">';
            for (const mes in data) {
              html += `
                <div class="fila-mes">
                  <label>${mes.charAt(0).toUpperCase() + mes.slice(1)}:</label>
                  <input type="number" name="${mes}" value="${data[mes]}" min="0" max="100" required>
                </div>`;
            }
            html += '</div>';
            contenedor.innerHTML = html;
            boton.classList.remove('oculto');
          }
        });
    }
    </script>

    <!-- ===================== LISTADO ===================== -->
    <section class="panel-section ventas-lista">
      <h2>📋 Ventas Registradas</h2>
      <table class="tabla-ventas">
        <tr>
          <th>Laptop</th>
          <th>Enero</th><th>Febrero</th><th>Marzo</th><th>Abril</th><th>Mayo</th><th>Junio</th>
          <th>Julio</th><th>Agosto</th><th>Septiembre</th><th>Octubre</th><th>Noviembre</th><th>Diciembre</th>
        </tr>
        <?php
        $ventas = $conn->query("
          SELECT v.*, l.nombre AS laptop
          FROM ventas v
          JOIN laptops l ON v.laptop_id = l.id
          ORDER BY l.nombre ASC
        ");
        if ($ventas->num_rows > 0) {
          while ($v = $ventas->fetch_assoc()) {
            echo "<tr>
              <td>" . htmlspecialchars($v['laptop']) . "</td>
              <td>{$v['enero']}</td><td>{$v['febrero']}</td><td>{$v['marzo']}</td><td>{$v['abril']}</td>
              <td>{$v['mayo']}</td><td>{$v['junio']}</td><td>{$v['julio']}</td><td>{$v['agosto']}</td>
              <td>{$v['septiembre']}</td><td>{$v['octubre']}</td><td>{$v['noviembre']}</td><td>{$v['diciembre']}</td>
            </tr>";
          }
        } else {
          echo "<tr><td colspan='13'>No hay ventas registradas.</td></tr>";
        }
        ?>
      </table>
    </section>

  </main>

  <footer class="admin-footer">
    <p>&copy; <?= date('Y') ?> TecShop. Todos los derechos reservados.</p>
  </footer>

  <script>
    function mostrarSeccion(id) {
      document.querySelectorAll('.panel-section').forEach(s => s.classList.add('oculto'));
      document.getElementById(id).classList.remove('oculto');
    }
  </script>
</body>
</html>

<?php $conn->close(); ?>
