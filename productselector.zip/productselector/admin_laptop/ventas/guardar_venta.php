<?php
include '../../conexion.php';

// Validar ID
$laptop_id = isset($_POST['laptop_id']) ? intval($_POST['laptop_id']) : 0;
if ($laptop_id <= 0) {
  die("Error: ID de laptop no válido.");
}

// Lista de meses
$meses = [
  'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
  'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'
];

// Recolectar datos
$valores = [];
foreach ($meses as $mes) {
  $valores[$mes] = isset($_POST[$mes]) ? intval($_POST[$mes]) : 0;
}

// Verificar si existe registro
$stmt_check = $conn->prepare("SELECT id FROM ventas WHERE laptop_id = ?");
$stmt_check->bind_param("i", $laptop_id);
$stmt_check->execute();
$stmt_check->store_result();

if ($stmt_check->num_rows > 0) {
  // Actualizar
  $sql = "UPDATE ventas SET 
    enero=?, febrero=?, marzo=?, abril=?, mayo=?, junio=?, 
    julio=?, agosto=?, septiembre=?, octubre=?, noviembre=?, diciembre=? 
    WHERE laptop_id=?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param(
    "iiiiiiiiiiiii",
    $valores['enero'], $valores['febrero'], $valores['marzo'], $valores['abril'],
    $valores['mayo'], $valores['junio'], $valores['julio'], $valores['agosto'],
    $valores['septiembre'], $valores['octubre'], $valores['noviembre'], $valores['diciembre'],
    $laptop_id
  );
  $stmt->execute();
  $stmt->close();
} else {
  // Insertar
  $sql = "INSERT INTO ventas (
    laptop_id, enero, febrero, marzo, abril, mayo, junio,
    julio, agosto, septiembre, octubre, noviembre, diciembre
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param(
    "iiiiiiiiiiiii",
    $laptop_id,
    $valores['enero'], $valores['febrero'], $valores['marzo'], $valores['abril'],
    $valores['mayo'], $valores['junio'], $valores['julio'], $valores['agosto'],
    $valores['septiembre'], $valores['octubre'], $valores['noviembre'], $valores['diciembre']
  );
  $stmt->execute();
  $stmt->close();
}

$stmt_check->close();
$conn->close();

header("Location: panel_ventas.php?success=1");
exit;
?>
