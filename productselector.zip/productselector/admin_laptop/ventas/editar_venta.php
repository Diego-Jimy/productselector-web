<?php
include '../../conexion.php';

// ✅ Obtener el ID de la laptop
$laptop_id = intval($_POST['laptop_id']);
if ($laptop_id <= 0) {
  header("Location: panel_ventas.php?error=sin_laptop");
  exit;
}

// ✅ Lista de meses esperados
$meses = [
  'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
  'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'
];

// ✅ Recolectar nuevos valores enviados
$valores = [];
foreach ($meses as $mes) {
  $valores[$mes] = isset($_POST[$mes]) ? intval($_POST[$mes]) : 0;
}

// ✅ Actualizar los valores existentes
$update_sql = "
  UPDATE ventas SET
    enero=?, febrero=?, marzo=?, abril=?, mayo=?, junio=?,
    julio=?, agosto=?, septiembre=?, octubre=?, noviembre=?, diciembre=?
  WHERE laptop_id=?
";
$stmt = $conn->prepare($update_sql);
$stmt->bind_param(
  "iiiiiiiiiiiii",
  $valores['enero'], $valores['febrero'], $valores['marzo'], $valores['abril'],
  $valores['mayo'], $valores['junio'], $valores['julio'], $valores['agosto'],
  $valores['septiembre'], $valores['octubre'], $valores['noviembre'], $valores['diciembre'],
  $laptop_id
);
$stmt->execute();
$stmt->close();
$conn->close();

// ✅ Redirigir con mensaje de éxito
header("Location: panel_ventas.php?edit_success=1");
exit;
?>
