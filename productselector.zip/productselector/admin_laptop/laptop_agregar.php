<?php
include '../conexion.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>➕ Agregar Laptop | TecShop</title>
  <link href="../style.css" rel="stylesheet">
</head>
<body>
  <h1>➕ Agregar Nueva Laptop</h1>

  <form action="guardar_laptop.php" method="POST" enctype="multipart/form-data">
    <label>Serie</label>
    <input type="text" name="serie" required placeholder="Ej: LAP123">

    <label>Nombre</label>
    <input type="text" name="nombre" required placeholder="Ej: Lenovo IdeaPad 3">

    <label>Tipo</label>
    <input type="text" name="tipo" value="laptop" readonly>

    <label>Procesador</label>
    <select name="procesador_id" required>
      <option value="">Seleccionar...</option>
      <?php
      $result = $conn->query("SELECT id, nombre FROM procesadores ORDER BY nombre ASC");
      while ($row = $result->fetch_assoc()) {
        echo "<option value='{$row['id']}'>" . htmlspecialchars($row['nombre']) . "</option>";
      }
      ?>
    </select>

    <label>Precio (S/)</label>
    <input type="number" step="0.01" name="precio" required placeholder="Ej: 3599.00">

    <h3>Detalles técnicos</h3>
    <label>Marca:</label><input type="text" name="marca">
    <label>Memoria RAM:</label><input type="text" name="ram">
    <label>Almacenamiento:</label><input type="text" name="almacenamiento">
    <label>Pantalla:</label><input type="text" name="pantalla">
    <label>Sistema Operativo:</label><input type="text" name="so">
    <label>Batería:</label><input type="text" name="bateria">
    <label>Descripción:</label><textarea name="descripcion" rows="3"></textarea>

    <h3>📸 Imágenes</h3>
    <label>Imagen principal:</label>
    <input type="file" name="imagen" accept="image/*">

    <label>Imagen abierta:</label>
    <input type="file" name="imagen_abierta" accept="image/*">

    <label>Imagen cerrada:</label>
    <input type="file" name="imagen_cerrada" accept="image/*">

    <label>Imagen interna:</label>
    <input type="file" name="imagen_interna" accept="image/*">

    <button type="submit">💾 Guardar Laptop</button>
  </form>

  <a href="panel_laptop.php">⬅ Volver</a>
</body>
</html>
