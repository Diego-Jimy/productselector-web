<?php
include '../conexion.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $serie = trim($_POST['serie']);

    if ($id <= 0 || empty($serie)) {
        echo "<script>alert('⚠️ Datos inválidos.'); window.location='panel_laptop.php';</script>";
        exit;
    }

    
    $stmt = $conn->prepare("SELECT imagen FROM laptops WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows === 0) {
        echo "<script>alert('❌ No se encontró la laptop.'); window.location='panel_laptop.php';</script>";
        exit;
    }
    $laptop = $res->fetch_assoc();
    $imagen_principal = $laptop['imagen'] ?? '';
    $stmt->close();

    
    $sqlImgs = $conn->prepare("SELECT imagen FROM laptop_imagenes WHERE laptop_id = ?");
    $sqlImgs->bind_param("i", $id);
    $sqlImgs->execute();
    $resImgs = $sqlImgs->get_result();
    while ($img = $resImgs->fetch_assoc()) {
        $rutaImg = "../img/laptops/" . $img['imagen'];
        if (file_exists($rutaImg)) {
            unlink($rutaImg);
        }
    }
    $sqlImgs->close();

    
    $conn->query("DELETE FROM laptop_imagenes WHERE laptop_id = $id");
    $conn->query("DELETE FROM laptop_programa WHERE laptop_id = $id");
    $conn->query("DELETE FROM laptop_carreras WHERE laptop_id = $id");
    $conn->query("DELETE FROM detalles WHERE laptop_id = $id");
    $conn->query("DELETE FROM ventas WHERE laptop_id = $id");

    
    $del = $conn->prepare("DELETE FROM laptops WHERE id = ?");
    $del->bind_param("i", $id);

    if ($del->execute() && $del->affected_rows > 0) {
        
        if (!empty($imagen_principal) && $imagen_principal !== "laptop.png") {
            $ruta = "../img/laptops/" . $imagen_principal;
            if (file_exists($ruta)) {
                unlink($ruta);
            }
        }

        echo "<script>alert('✅ Laptop e imágenes eliminadas correctamente.'); window.location='panel_laptop.php';</script>";
    } else {
        echo "<script>alert('❌ Error al eliminar la laptop: " . htmlspecialchars($del->error) . "'); window.location='panel_laptop.php';</script>";
    }

    $del->close();
    $conn->close();
} else {
    header("Location: panel_laptop.php");
    exit;
}
?>
