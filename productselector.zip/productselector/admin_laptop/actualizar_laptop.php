<?php
include '../conexion.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $serie_original = trim($_POST['serie_original']);
    $serie = trim($_POST['serie']);
    $nombre = trim($_POST['nombre']);
    $tipo = trim($_POST['tipo']);
    $procesador_id = intval($_POST['procesador_id']);
    $precio = floatval($_POST['precio']);

    $marca = trim($_POST['marca']);
    $ram = trim($_POST['ram']);
    $almacenamiento = trim($_POST['almacenamiento']);
    $pantalla = trim($_POST['pantalla']);
    $so = trim($_POST['so']);
    $bateria = trim($_POST['bateria']);
    $descripcion = trim($_POST['descripcion']);

    
    $imagen = null;
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        $tipoArchivo = mime_content_type($_FILES['imagen']['tmp_name']);
        if (strpos($tipoArchivo, 'image/') === 0) {
            if ($_FILES['imagen']['size'] > 2 * 1024 * 1024) {
                echo "<script>alert('⚠️ La imagen no debe superar los 2 MB.'); window.location='panel_laptop.php';</script>";
                exit;
            }
            $imagen_nombre = time() . "_" . basename($_FILES['imagen']['name']);
            $rutaDestino = "../img/laptops/" . $imagen_nombre;
            if (!move_uploaded_file($_FILES['imagen']['tmp_name'], $rutaDestino)) {
                echo "<script>alert('⚠️ Error subiendo la imagen.'); window.location='panel_laptop.php';</script>";
                exit;
            }
            $imagen = $imagen_nombre;
        } else {
            echo "<script>alert('⚠️ Solo se permiten imágenes válidas.'); window.location='panel_laptop.php';</script>";
            exit;
        }
    }

    
    if ($imagen) {
        $sql = "UPDATE laptops 
                SET serie=?, nombre=?, tipo=?, precio=?, procesador_id=?, imagen=? 
                WHERE serie=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssdiss", $serie, $nombre, $tipo, $precio, $procesador_id, $imagen, $serie_original);
    } else {
        $sql = "UPDATE laptops 
                SET serie=?, nombre=?, tipo=?, precio=?, procesador_id=? 
                WHERE serie=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssdis", $serie, $nombre, $tipo, $precio, $procesador_id, $serie_original);
    }

    if (!$stmt->execute()) {
        echo "<script>alert('❌ Error al actualizar laptop: " . htmlspecialchars($stmt->error) . "'); window.location='panel_laptop.php';</script>";
        exit;
    }
    $stmt->close();

    
    $res = $conn->prepare("SELECT id FROM laptops WHERE serie = ?");
    $res->bind_param("s", $serie);
    $res->execute();
    $laptop = $res->get_result()->fetch_assoc();
    $res->close();

    if (!$laptop) {
        echo "<script>alert('❌ No se encontró la laptop actualizada.'); window.location='panel_laptop.php';</script>";
        exit;
    }
    $laptop_id = intval($laptop['id']);

    
    $sql2 = "UPDATE detalles 
             SET marca=?, ram=?, almacenamiento=?, pantalla=?, sistema_operativo=?, bateria=?, descripcion=? 
             WHERE laptop_id=?";
    $stmt2 = $conn->prepare($sql2);
    $stmt2->bind_param("sssssssi", $marca, $ram, $almacenamiento, $pantalla, $so, $bateria, $descripcion, $laptop_id);
    $stmt2->execute();
    $stmt2->close();

    
    $tipos = ['imagen_abierta' => 'abierta', 'imagen_cerrada' => 'cerrada', 'imagen_interna' => 'interna'];
    foreach ($tipos as $campo => $tipo) {
        if (isset($_FILES[$campo]) && $_FILES[$campo]['error'] === UPLOAD_ERR_OK) {
            $tipoArchivo = mime_content_type($_FILES[$campo]['tmp_name']);
            if (strpos($tipoArchivo, 'image/') === 0) {
                if ($_FILES[$campo]['size'] > 2 * 1024 * 1024) {
                    continue;
                }
                $nuevo_nombre = time() . "_" . basename($_FILES[$campo]['name']);
                $destino = "../img/laptops/" . $nuevo_nombre;
                move_uploaded_file($_FILES[$campo]['tmp_name'], $destino);

                
                $resOld = $conn->prepare("SELECT imagen FROM laptop_imagenes WHERE laptop_id=? AND tipo=?");
                $resOld->bind_param("is", $laptop_id, $tipo);
                $resOld->execute();
                $old = $resOld->get_result()->fetch_assoc();
                $resOld->close();
                if ($old && !empty($old['imagen'])) {
                    $oldPath = "../img/laptops/" . $old['imagen'];
                    if (file_exists($oldPath)) unlink($oldPath);
                }

                
                $check = $conn->prepare("SELECT COUNT(*) AS c FROM laptop_imagenes WHERE laptop_id=? AND tipo=?");
                $check->bind_param("is", $laptop_id, $tipo);
                $check->execute();
                $exists = $check->get_result()->fetch_assoc()['c'] > 0;
                $check->close();

                if ($exists) {
                    $up = $conn->prepare("UPDATE laptop_imagenes SET imagen=? WHERE laptop_id=? AND tipo=?");
                    $up->bind_param("sis", $nuevo_nombre, $laptop_id, $tipo);
                    $up->execute();
                    $up->close();
                } else {
                    $ins = $conn->prepare("INSERT INTO laptop_imagenes (laptop_id, tipo, imagen) VALUES (?, ?, ?)");
                    $ins->bind_param("iss", $laptop_id, $tipo, $nuevo_nombre);
                    $ins->execute();
                    $ins->close();
                }
            }
        }
    }

    
    $conn->query("DELETE FROM laptop_carreras WHERE laptop_id=$laptop_id");
    if (!empty($_POST['carreras'])) {
        $stmt3 = $conn->prepare("INSERT INTO laptop_carreras (laptop_id, carrera_id) VALUES (?, ?)");
        foreach ($_POST['carreras'] as $cid) {
            $c = intval($cid);
            $stmt3->bind_param("ii", $laptop_id, $c);
            $stmt3->execute();
        }
        $stmt3->close();
    }

    
    $conn->query("DELETE FROM laptop_programa WHERE laptop_id=$laptop_id");
    if (!empty($_POST['programas'])) {
        $stmt4 = $conn->prepare("INSERT INTO laptop_programa (laptop_id, programa_id) VALUES (?, ?)");
        foreach ($_POST['programas'] as $pid) {
            $p = intval($pid);
            $stmt4->bind_param("ii", $laptop_id, $p);
            $stmt4->execute();
        }
        $stmt4->close();
    }

    echo "<script>alert('✅ Laptop actualizada correctamente con todas sus imágenes.'); window.location='panel_laptop.php';</script>";
    $conn->close();
}
?>
