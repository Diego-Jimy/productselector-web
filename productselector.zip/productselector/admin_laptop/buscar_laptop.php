<?php
include '../conexion.php';

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
  header("Location: panel_laptop.php");
  exit;
}

$serie = trim($_POST['serie']);

$sql = "SELECT l.*, p.nombre AS procesador_nombre, d.marca, d.ram, d.almacenamiento, d.pantalla, 
               d.sistema_operativo, d.bateria, d.descripcion
        FROM laptops l
        LEFT JOIN procesadores p ON l.procesador_id = p.id
        LEFT JOIN detalles d ON l.id = d.laptop_id
        WHERE l.serie = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $serie);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  echo "<script>alert('❌ No se encontró ninguna laptop con esa serie.'); window.location='panel_laptop.php';</script>";
  exit;
}

$laptop = $result->fetch_assoc();
$laptop_id = $laptop['id'];


$imagenesExtra = [];
$resImgs = $conn->query("SELECT tipo, imagen FROM laptop_imagenes WHERE laptop_id = $laptop_id");
while ($r = $resImgs->fetch_assoc()) {
  $imagenesExtra[$r['tipo']] = $r['imagen'];
}


$carreras_sel = [];
$resCarreras = $conn->query("SELECT carrera_id FROM laptop_carreras WHERE laptop_id = $laptop_id");
while ($r = $resCarreras->fetch_assoc()) {
  $carreras_sel[] = $r['carrera_id'];
}

$programas_sel = [];
$resProgramas = $conn->query("SELECT programa_id FROM laptop_programa WHERE laptop_id = $laptop_id");
while ($r = $resProgramas->fetch_assoc()) {
  $programas_sel[] = $r['programa_id'];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title> Editar Laptop | TecShop</title>
  <link rel="stylesheet" href="admin_laptop.css">
</head>

<body class="admin-body">
<header class="admin-header">
  <h1> Editar Laptop - <?= htmlspecialchars($laptop['nombre']) ?></h1>
  <a href="panel_laptop.php" class="admin-volver">⬅ Volver</a>
</header>

<main class="admin-main">
  <form action="actualizar_laptop.php" method="POST" enctype="multipart/form-data" class="admin-form">
    <input type="hidden" name="serie_original" value="<?= htmlspecialchars($laptop['serie']) ?>">

    <label>Serie:</label>
    <input type="text" name="serie" value="<?= htmlspecialchars($laptop['serie']) ?>" readonly style="background:#eee; cursor:not-allowed;">

    <label>Nombre:</label>
    <input type="text" name="nombre" value="<?= htmlspecialchars($laptop['nombre']) ?>" required>

    <label>Tipo:</label>
    <input type="text" name="tipo" value="<?= htmlspecialchars($laptop['tipo']) ?>" readonly>

    <label>Procesador:</label>
    <select name="procesador_id" required>
      <option value="">-- Selecciona --</option>
      <?php
      $procesadores = $conn->query("SELECT id, nombre FROM procesadores ORDER BY nombre ASC");
      while ($p = $procesadores->fetch_assoc()) {
          $sel = ($p['id'] == $laptop['procesador_id']) ? 'selected' : '';
          echo "<option value='{$p['id']}' $sel>" . htmlspecialchars($p['nombre']) . "</option>";
      }
      ?>
    </select>

    <label>Precio (S/):</label>
    <input type="number" step="0.01" name="precio" value="<?= htmlspecialchars($laptop['precio']) ?>" required>

    <h3> Detalles técnicos</h3>
    <label>Marca:</label><input type="text" name="marca" value="<?= htmlspecialchars($laptop['marca']) ?>">
    <label>RAM:</label><input type="text" name="ram" value="<?= htmlspecialchars($laptop['ram']) ?>">
    <label>Almacenamiento:</label><input type="text" name="almacenamiento" value="<?= htmlspecialchars($laptop['almacenamiento']) ?>">
    <label>Pantalla:</label><input type="text" name="pantalla" value="<?= htmlspecialchars($laptop['pantalla']) ?>">
    <label>Sistema Operativo:</label><input type="text" name="so" value="<?= htmlspecialchars($laptop['sistema_operativo']) ?>">
    <label>Batería:</label><input type="text" name="bateria" value="<?= htmlspecialchars($laptop['bateria']) ?>">
    <label>Descripción:</label><textarea name="descripcion" rows="3"><?= htmlspecialchars($laptop['descripcion']) ?></textarea>

    <h3> Imágenes</h3>
    <p>Imagen principal:</p>
    <img src="../img/laptops/<?= htmlspecialchars($laptop['imagen']) ?>" width="180" alt="Principal">
    <input type="file" name="imagen" accept="image/*">

    <p>Imagen abierta:</p>
    <?php if (!empty($imagenesExtra['abierta'])): ?>
      <img src="../img/laptops/<?= htmlspecialchars($imagenesExtra['abierta']) ?>" width="180" alt="Abierta">
    <?php endif; ?>
    <input type="file" name="imagen_abierta" accept="image/*">

    <p>Imagen cerrada:</p>
    <?php if (!empty($imagenesExtra['cerrada'])): ?>
      <img src="../img/laptops/<?= htmlspecialchars($imagenesExtra['cerrada']) ?>" width="180" alt="Cerrada">
    <?php endif; ?>
    <input type="file" name="imagen_cerrada" accept="image/*">

    <p>Imagen interna:</p>
    <?php if (!empty($imagenesExtra['interna'])): ?>
      <img src="../img/laptops/<?= htmlspecialchars($imagenesExtra['interna']) ?>" width="180" alt="Interna">
    <?php endif; ?>
    <input type="file" name="imagen_interna" accept="image/*">

    <h3>🎓 Carreras compatibles</h3>
    <div class="checkbox-group">
      <?php
      $carreras = $conn->query("SELECT id, nombre FROM carreras ORDER BY nombre ASC");
      while ($c = $carreras->fetch_assoc()) {
          $checked = in_array($c['id'], $carreras_sel) ? 'checked' : '';
          echo "
          <div class='checkbox-item'>
            <input type='checkbox' name='carreras[]' id='car-{$c['id']}' value='{$c['id']}' $checked>
            <label for='car-{$c['id']}'>" . htmlspecialchars($c['nombre']) . "</label>
          </div>";
      }
      ?>
    </div>

    <h3> Programas compatibles</h3>
    <div class="checkbox-group">
      <?php
      $programas = $conn->query("SELECT id, nombre FROM programas ORDER BY nombre ASC");
      while ($pr = $programas->fetch_assoc()) {
          $checked = in_array($pr['id'], $programas_sel) ? 'checked' : '';
          echo "
          <div class='checkbox-item'>
            <input type='checkbox' name='programas[]' id='prog-{$pr['id']}' value='{$pr['id']}' $checked>
            <label for='prog-{$pr['id']}'>" . htmlspecialchars($pr['nombre']) . "</label>
          </div>";
      }
      ?>
    </div>

    <button type="submit" class="btn-editar">💾 Guardar cambios</button>
  </form>
</main>

<footer class="admin-footer">
  <p>&copy; <?= date('Y') ?> TecShop. Todos los derechos reservados.</p>
</footer>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
