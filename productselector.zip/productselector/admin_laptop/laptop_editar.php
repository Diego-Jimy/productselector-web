<?php include '../conexion.php'; ?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>✏️ Editar Laptop | TecShop</title>
  <link href="../style.css" rel="stylesheet">
</head>
<body>
  <h1>✏️ Editar Laptop</h1>
  <form action="buscar_laptop.php" method="POST">
    <label>Ingrese la <strong>serie</strong> de la laptop:</label>
    <input type="text" name="serie" required placeholder="Ej: LAP123">
    <button type="submit">🔍 Buscar</button>
  </form>
  <a href="panel_laptop.php">⬅ Volver</a>
</body>
</html>
