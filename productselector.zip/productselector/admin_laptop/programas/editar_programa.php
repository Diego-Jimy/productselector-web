<?php
include '../../conexion.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = intval($_POST['id']);
    $nombre = trim($_POST['nombre']);
    $icono = null;

    if (empty($nombre)) {
        echo "<script>alert('⚠️ El nombre es obligatorio.'); window.location='panel_programa.php';</script>";
        exit;
    }

    if (isset($_FILES['icono']) && $_FILES['icono']['error'] === UPLOAD_ERR_OK) {
        $tipoArchivo = mime_content_type($_FILES['icono']['tmp_name']);
        if (strpos($tipoArchivo, 'image/') === 0) {
            $nombreArchivo = time() . '_' . basename($_FILES['icono']['name']);
            $rutaDestino = '../../img/programas/' . $nombreArchivo;
            if (!file_exists('../../img/programas')) mkdir('../../img/programas', 0777, true);
            move_uploaded_file($_FILES['icono']['tmp_name'], $rutaDestino);
            $icono = $nombreArchivo;
        } else {
            echo "<script>alert('⚠️ Solo se permiten imágenes válidas.'); window.location='panel_programa.php';</script>";
            exit;
        }
    }

    if ($icono) {
        $sql = "UPDATE programas SET nombre=?, icono=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $nombre, $icono, $id);
    } else {
        $sql = "UPDATE programas SET nombre=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $nombre, $id);
    }

    if ($stmt->execute()) {
        echo "<script>alert('✅ Programa actualizado correctamente.'); window.location='panel_programa.php';</script>";
    } else {
        echo "<script>alert('❌ Error al actualizar.'); window.location='panel_programa.php';</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
