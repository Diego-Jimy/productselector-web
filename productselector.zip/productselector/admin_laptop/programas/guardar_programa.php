<?php
include '../../conexion.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre = trim($_POST['nombre']);
    $icono = "programa.png";

    if (empty($nombre)) {
        echo "<script>alert('⚠️ El nombre del programa es obligatorio.'); window.location='panel_programa.php';</script>";
        exit;
    }

    if (isset($_FILES['icono']) && $_FILES['icono']['error'] === UPLOAD_ERR_OK) {
        $tipoArchivo = mime_content_type($_FILES['icono']['tmp_name']);
        if (strpos($tipoArchivo, 'image/') === 0) {
            $nombreArchivo = time() . '_' . basename($_FILES['icono']['name']);
            $rutaDestino = '../../img/programas/' . $nombreArchivo;
            if (!file_exists('../../img/programas')) {
                mkdir('../../img/programas', 0777, true);
            }
            move_uploaded_file($_FILES['icono']['tmp_name'], $rutaDestino);
            $icono = $nombreArchivo;
        } else {
            echo "<script>alert('⚠️ Solo se permiten imágenes válidas.'); window.location='panel_programa.php';</script>";
            exit;
        }
    }

    $stmt = $conn->prepare("INSERT INTO programas (nombre, icono) VALUES (?, ?)");
    if (!$stmt) {
        echo "<script>alert('❌ Error: " . $conn->error . "'); window.location='panel_programa.php';</script>";
        exit;
    }

    $stmt->bind_param("ss", $nombre, $icono);

    if ($stmt->execute()) {
        echo "<script>alert('✅ Programa agregado correctamente.'); window.location='panel_programa.php';</script>";
    } else {
        echo "<script>alert('❌ Error al guardar: " . $stmt->error . "'); window.location='panel_programa.php';</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
