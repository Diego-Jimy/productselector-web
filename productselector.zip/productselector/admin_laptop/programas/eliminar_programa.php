<?php
include '../../conexion.php';
header('Content-Type: text/plain; charset=utf-8');

$id = intval($_POST['id'] ?? 0);
if ($id <= 0) {
    echo "⚠️ ID no válido.";
    exit;
}


$conn->query("DELETE FROM laptop_programa WHERE programa_id = $id");


$stmt = $conn->prepare("DELETE FROM programas WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo "✅ Programa eliminado correctamente.";
} else {
    echo "❌ Error al eliminar: " . $stmt->error;
}

$stmt->close();
$conn->close();
