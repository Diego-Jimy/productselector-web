<?php include '../../conexion.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title> Panel de Programas | TecShop</title>
  <link rel="stylesheet" href="../admin_laptop.css"/>
  <link rel="stylesheet" href="panel_programa.css"/>
</head>

<body class="admin-body">
  <header class="admin-header">
    <h1>Panel de Administración - Programas</h1>
    <a class="admin-volver" href="../panel_laptop.php">⬅ Volver al Panel de Laptops</a>
  </header>

  <main class="admin-main">
    <div class="acciones-principales">
      <button class="btn-accion" onclick="mostrarSeccion('agregar')">➕ Agregar</button>
      <button class="btn-accion editar" onclick="mostrarSeccion('editar')">✏️ Editar</button>
      <button class="btn-accion eliminar" onclick="mostrarSeccion('eliminar')">🗑️ Eliminar</button>
    </div>

    
    <section id="agregar" class="panel-section oculto">
      <h2>Agregar nuevo Programa</h2>
      <form action="guardar_programa.php" method="POST" enctype="multipart/form-data" class="admin-form">
        <label>Nombre del programa:</label>
        <input type="text" name="nombre" required placeholder="Ej: AutoCAD, Photoshop, SolidWorks">

        <label>Ícono (opcional):</label>
        <input type="file" name="icono" accept="image/*">

        <button type="submit" class="btn-agregar">✅ Guardar Programa</button>
      </form>
    </section>

   
    <section id="editar" class="panel-section oculto">
      <h2>Editar Programa existente</h2>
      <form action="editar_programa.php" method="POST" class="admin-form">
        <label>Seleccione un programa:</label>
        <select name="programa_id" required>
          <option value="">-- Selecciona --</option>
          <?php
          $result = $conn->query("SELECT id, nombre FROM programas ORDER BY nombre ASC");
          while ($row = $result->fetch_assoc()) {
            echo "<option value='{$row['id']}'>" . htmlspecialchars($row['nombre']) . "</option>";
          }
          ?>
        </select>
        <button type="submit" class="btn-editar">✏️ Editar</button>
      </form>
    </section>

    
    <section id="eliminar" class="panel-section oculto">
      <h2>Eliminar Programa</h2>
      <form id="form-eliminar" onsubmit="return eliminarPrograma(event)" class="admin-form">
        <label>Seleccione un programa:</label>
        <select id="programa_id" name="programa_id" required>
          <option value="">-- Selecciona --</option>
          <?php
          $result = $conn->query("SELECT id, nombre FROM programas ORDER BY nombre ASC");
          while ($row = $result->fetch_assoc()) {
            echo "<option value='{$row['id']}'>" . htmlspecialchars($row['nombre']) . "</option>";
          }
          ?>
        </select>
        <button type="submit" class="btn-eliminar">🗑️ Eliminar</button>
      </form>
    </section>

    
    <section class="panel-section programas-lista">
      <h2>📋 Programas Registrados</h2>
      <table class="tabla-programas">
        <tr>
          <th>Ícono</th>
          <th>Nombre</th>
        </tr>
        <?php
        $lista = $conn->query("SELECT nombre, icono FROM programas ORDER BY nombre ASC");
        if ($lista->num_rows > 0) {
          while ($p = $lista->fetch_assoc()) {
            echo "<tr>
                    <td><img src='../../img/programas/" . htmlspecialchars($p['icono']) . "' alt='icono'></td>
                    <td>" . htmlspecialchars($p['nombre']) . "</td>
                  </tr>";
          }
        } else {
          echo "<tr><td colspan='2'>No hay programas registrados.</td></tr>";
        }
        ?>
      </table>
    </section>
  </main>

  <footer class="admin-footer">
    <p>&copy; <?= date('Y') ?> TecShop. Todos los derechos reservados.</p>
  </footer>

  <script>
    function mostrarSeccion(id) {
      document.querySelectorAll('.panel-section').forEach(s => s.classList.add('oculto'));
      document.getElementById(id).classList.remove('oculto');
    }

    async function eliminarPrograma(e) {
      e.preventDefault();
      const select = document.getElementById('programa_id');
      const id = select.value;
      const nombre = select.options[select.selectedIndex].text;

      if (!id) {
        alert("⚠️ Por favor selecciona un programa.");
        return false;
      }

      
      const confirmar = confirm(`¿Deseas eliminar el programa "${nombre}"?`);
      if (!confirmar) return false;

     
      const res = await fetch('ver_asociaciones_programa.php?id=' + id);
      const data = await res.json();

      if (data.laptops.length > 0) {
        
        let lista = "";
        data.laptops.forEach(l => {
          lista += "\n - " + l;
        });

        const mensaje = `⚠️ El programa "${nombre}" está asociado con las siguientes laptops:` +
                        `${lista}\n\n¿Deseas continuar y eliminarlo de todas ellas?`;
        const confirmar2 = confirm(mensaje);
        if (!confirmar2) return false;
      }

      
      const resp = await fetch('eliminar_programa.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id=' + encodeURIComponent(id)
      });

      const texto = await resp.text();
      alert(texto.trim());
      window.location.reload();
    }
  </script>
</body>
</html>

<?php $conn->close(); ?>
