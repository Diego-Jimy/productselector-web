<?php
include '../../conexion.php';
header('Content-Type: application/json; charset=utf-8');

$id = intval($_GET['id'] ?? 0);
$laptops = [];

$stmt = $conn->prepare("
  SELECT l.nombre
  FROM laptops l
  INNER JOIN laptop_programa lp ON l.id = lp.laptop_id
  WHERE lp.programa_id = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();

while ($row = $res->fetch_assoc()) {
  $laptops[] = $row['nombre'];
}

echo json_encode(['laptops' => $laptops]);
$stmt->close();
$conn->close();
