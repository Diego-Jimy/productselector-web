<?php include '../conexion.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Derecho - Notaría | TecShop</title>
  <link href="../style.css?v=<?= time(); ?>" rel="stylesheet"/>
</head>

<body>
  <header>
    <div class="header-content">
      <img src="../img/logo.png" alt="Logo TecShop" class="logo">
      <h1>Derecho - Notaría</h1>
    </div>
  </header>

  <section class="filtros">
    <button class="filtro-btn active" data-cat="todos">Todos</button>
    <button class="filtro-btn" data-cat="corei5">Intel Core i5</button>
    <button class="filtro-btn" data-cat="ryzen5">AMD Ryzen 5</button>
  </section>

  <main>
    <?php
    // ✅ TODAS las laptops
    $sqlTodos = "
      SELECT l.id, l.nombre, l.precio, l.imagen, p.nombre AS procesador, d.descripcion
      FROM laptops l
      JOIN procesadores p ON l.procesador_id = p.id
      LEFT JOIN detalles d ON d.laptop_id = l.id
      ORDER BY l.precio ASC
    ";
    $resultTodos = $conn->query($sqlTodos);
    $todos = [];
    while ($row = $resultTodos->fetch_assoc()) $todos[] = $row;

    // ✅ Solo i5 / Ryzen 5 (mínimo para Notaría)
    $sql = "
      SELECT l.id, l.nombre, l.precio, l.imagen, p.nombre AS procesador, d.descripcion
      FROM laptops l
      JOIN procesadores p ON l.procesador_id = p.id
      LEFT JOIN detalles d ON d.laptop_id = l.id
      WHERE p.nombre IN ('Intel Core i5', 'AMD Ryzen 5')
      ORDER BY l.precio ASC
    ";
    $result = $conn->query($sql);
    $corei5 = $ryzen5 = [];

    if ($result && $result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        $proc = strtolower($row['procesador']);
        if (strpos($proc, 'i5') !== false) $corei5[] = $row;
        if (strpos($proc, 'ryzen 5') !== false) $ryzen5[] = $row;
      }
    }

    function renderCat($cat, $items, $visible = false) {
      $display = $visible ? "" : "style='display:none;'";
      echo "<section class='categoria $cat' $display><div class='grid'>";
      if (!empty($items)) {
        foreach ($items as $item) {
          $desc = htmlspecialchars($item['descripcion'] ?? '');
          echo "
          <a class='card' href='../detalles/detalle-laptop.php?id={$item['id']}'>
            <img src='../img/laptops/{$item['imagen']}?v=" . time() . "' alt='{$item['nombre']}' loading='lazy' onerror=\"this.src='../img/laptop.png'\">
            <h2>{$item['nombre']}</h2>" .
            ($desc ? "<p class='descripcion'><strong>Descripción:</strong> $desc</p>" : "") .
            "<p class='price-oferta'>S/ " . number_format($item['precio'], 2) . "</p>
          </a>";
        }
      } else {
        echo "<p class='mensaje-vacio'>No hay laptops disponibles.</p>";
      }
      echo "</div></section>";
    }

    renderCat("todos", $todos, true);
    renderCat("corei5", $corei5);
    renderCat("ryzen5", $ryzen5);
    ?>
  </main>

  <a class="volver" href="derecho.html">⬅ Volver</a>
  <footer><p>&copy; <?= date('Y') ?> TecShop. Todos los derechos reservados.</p></footer>

  <script>
    document.querySelectorAll(".filtro-btn").forEach(btn => {
      btn.onclick = () => {
        document.querySelectorAll(".filtro-btn").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        const cat = btn.dataset.cat;
        document.querySelectorAll(".categoria").forEach(c => {
          c.style.display = c.classList.contains(cat) ? "block" : "none";
        });
      };
    });
  </script>
</body>
</html>
<?php $conn->close(); ?>